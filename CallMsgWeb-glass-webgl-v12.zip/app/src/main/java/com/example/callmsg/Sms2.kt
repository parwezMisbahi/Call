package com.example.callmsg

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.util.JsonReader
import android.util.JsonWriter
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStreamReader
import java.io.OutputStreamWriter

// ---------- OTP pehchaan + copy ----------
object Otp {
    private val re = Regex("(?<!\\d)(\\d{4,8})(?!\\d)")
    private val kw = Regex(
        "otp|one.time|verification|verify|passcode|password|security code|login code|\\bcode\\b|\\bpin\\b",
        RegexOption.IGNORE_CASE
    )

    fun find(body: String): String? {
        if (!kw.containsMatchIn(body)) return null
        for (m in re.findAll(body)) {
            val s = m.range.first
            val before = body.substring(maxOf(0, s - 4), s).lowercase()
            if (before.contains("rs") || before.contains("inr") || before.contains("\u20B9")) continue
            return m.value
        }
        return null
    }
}

object Clip {
    fun copy(ctx: Context, text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("text", text))
    }
}

class OtpCopyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val code = intent.getStringExtra("code") ?: return
        Clip.copy(ctx, code)
        Toast.makeText(ctx, "OTP copied: $code", Toast.LENGTH_SHORT).show()
    }
}

// ---------- Auto-reply: ek number ko ghante mein sirf ek baar ----------
object AutoReply {
    private const val DEF = "Main abhi busy hoon, thodi der mein baat karta hoon."
    private fun sp(ctx: Context) = ctx.getSharedPreferences("autoreply", Context.MODE_PRIVATE)

    fun get(ctx: Context): JSONObject {
        val p = sp(ctx)
        return JSONObject()
            .put("on", p.getBoolean("on", false))
            .put("msg", p.getString("msg", DEF) ?: DEF)
            .put("sms", p.getBoolean("sms", true))
            .put("call", p.getBoolean("call", true))
    }

    fun set(ctx: Context, o: JSONObject) {
        sp(ctx).edit()
            .putBoolean("on", o.optBoolean("on"))
            .putString("msg", o.optString("msg").trim())
            .putBoolean("sms", o.optBoolean("sms", true))
            .putBoolean("call", o.optBoolean("call", true))
            .apply()
    }

    private fun reply(ctx: Context, num: String) {
        val p = sp(ctx)
        if (!p.getBoolean("on", false)) return
        val msg = (p.getString("msg", DEF) ?: "").trim()
        if (msg.isEmpty()) return
        // sirf asli phone number: naam wale sender (AX-HDFCBK) aur chhote code ko reply nahi
        if (num.any { it.isLetter() } || num.count { it.isDigit() } < 10) return
        if (Blocklist.isBlocked(ctx, num)) return
        val key = "last_" + Blocklist.norm(num)
        val now = System.currentTimeMillis()
        if (now - p.getLong(key, 0L) < 3600000L) return
        val e = p.edit()
        for ((k, v) in p.all) {
            if (k.startsWith("last_") && v is Long && now - v > 3600000L) e.remove(k)
        }
        e.putLong(key, now).apply()
        try { SmsHelper.send(ctx, num, msg) } catch (ex: Exception) { }
    }

    fun onSms(ctx: Context, addr: String) {
        if (sp(ctx).getBoolean("sms", true)) reply(ctx, addr)
    }

    fun onMissedCall(ctx: Context, num: String) {
        if (sp(ctx).getBoolean("call", true)) reply(ctx, num)
    }
}

// ---------- Scheduled SMS ----------
object Scheduler {
    private const val CH = "sched"
    private fun sp(ctx: Context) = ctx.getSharedPreferences("sched", Context.MODE_PRIVATE)

    fun list(ctx: Context): JSONArray =
        try { JSONArray(sp(ctx).getString("l", "[]")) } catch (e: Exception) { JSONArray() }

    private fun save(ctx: Context, a: JSONArray) {
        sp(ctx).edit().putString("l", a.toString()).apply()
    }

    private fun pi(ctx: Context, id: Int): PendingIntent = PendingIntent.getBroadcast(
        ctx, id, Intent(ctx, ScheduledSmsReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun exactOk(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        return ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    }

    private fun arm(ctx: Context, id: Int, at: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val p = pi(ctx, id)
        try {
            if (exactOk(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        }
    }

    fun add(ctx: Context, to: String, text: String, at: Long): Int {
        val id = (System.currentTimeMillis() % 1000000000L).toInt()
        val a = list(ctx)
        a.put(JSONObject().put("id", id).put("to", to).put("text", text).put("at", at))
        save(ctx, a)
        arm(ctx, id, at)
        return id
    }

    private fun without(ctx: Context, id: Int): Pair<JSONArray, JSONObject?> {
        val out = JSONArray()
        var found: JSONObject? = null
        val a = list(ctx)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optInt("id") == id) found = o else out.put(o)
        }
        return Pair(out, found)
    }

    fun cancel(ctx: Context, id: Int) {
        save(ctx, without(ctx, id).first)
        try { ctx.getSystemService(AlarmManager::class.java).cancel(pi(ctx, id)) } catch (e: Exception) { }
    }

    // alarm bajne par: entry nikaalo aur list se hatao
    fun take(ctx: Context, id: Int): JSONObject? {
        val r = without(ctx, id)
        if (r.second != null) save(ctx, r.first)
        return r.second
    }

    // phone restart ke baad alarm dobara lagao
    fun rearmAll(ctx: Context) {
        val a = list(ctx)
        val now = System.currentTimeMillis()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            arm(ctx, o.optInt("id"), maxOf(o.optLong("at"), now + 3000L))
        }
    }

    @Suppress("DEPRECATION")
    fun notifyDone(ctx: Context, to: String, ok: Boolean) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel(CH, "Scheduled SMS", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CH) else Notification.Builder(ctx)
        val who = SmsHelper.nameFor(ctx, to)
        b.setSmallIcon(android.R.drawable.sym_action_email)
            .setContentTitle(if (ok) "Scheduled SMS bheja gaya" else "Scheduled SMS nahi gaya")
            .setContentText(who)
            .setAutoCancel(true)
        try { nm.notify(7000 + (to.hashCode() and 0xfff), b.build()) } catch (e: Exception) { }
    }
}

class ScheduledSmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val e = Scheduler.take(ctx, id) ?: return
        val to = e.optString("to")
        var ok = true
        try { SmsHelper.send(ctx, to, e.optString("text")) } catch (ex: Exception) { ok = false }
        Scheduler.notifyDone(ctx, to, ok)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Scheduler.rearmAll(ctx)
    }
}

// ---------- Backup / Restore (SMS + block list, JSON file) ----------
object Backup {
    fun write(ctx: Context, uri: Uri): String {
        var n = 0
        val os = ctx.contentResolver.openOutputStream(uri, "w") ?: return "Error: file nahi khuli"
        val w = JsonWriter(OutputStreamWriter(os, "UTF-8"))
        try {
            w.beginObject()
            w.name("v").value(1L)
            w.name("blocked").beginArray()
            Blocklist.list(ctx).forEach { w.value(it) }
            w.endArray()
            w.name("sms").beginArray()
            ctx.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.READ),
                null, null, "date ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    w.beginObject()
                    w.name("a").value(c.getString(0) ?: "")
                    w.name("b").value(c.getString(1) ?: "")
                    w.name("d").value(c.getLong(2))
                    w.name("t").value(c.getInt(3).toLong())
                    w.name("r").value(c.getInt(4).toLong())
                    w.endObject()
                    n++
                }
            }
            w.endArray()
            w.endObject()
            w.flush()
        } finally {
            w.close()
        }
        return "Backup ho gaya: $n messages"
    }

    fun read(ctx: Context, uri: Uri): String {
        val have = HashSet<String>()
        ctx.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE), null, null, null
        )?.use { c ->
            while (c.moveToNext()) have.add("${c.getLong(2)}|${c.getString(0)}|${(c.getString(1) ?: "").hashCode()}")
        }
        var added = 0
        var skipped = 0
        val ins = ctx.contentResolver.openInputStream(uri) ?: return "Error: file nahi khuli"
        val r = JsonReader(InputStreamReader(ins, "UTF-8"))
        try {
            r.beginObject()
            while (r.hasNext()) {
                val top = r.nextName()
                if (top == "blocked") {
                    r.beginArray()
                    while (r.hasNext()) Blocklist.add(ctx, r.nextString())
                    r.endArray()
                } else if (top == "sms") {
                    r.beginArray()
                    while (r.hasNext()) {
                        var a = ""
                        var b = ""
                        var d = 0L
                        var t = 1
                        var rd = 1
                        r.beginObject()
                        while (r.hasNext()) {
                            when (r.nextName()) {
                                "a" -> a = r.nextString()
                                "b" -> b = r.nextString()
                                "d" -> d = r.nextLong()
                                "t" -> t = r.nextInt()
                                "r" -> rd = r.nextInt()
                                else -> r.skipValue()
                            }
                        }
                        r.endObject()
                        if (!have.add("$d|$a|${b.hashCode()}")) { skipped++; continue }
                        try {
                            ctx.contentResolver.insert(Telephony.Sms.CONTENT_URI, ContentValues().apply {
                                put(Telephony.Sms.ADDRESS, a)
                                put(Telephony.Sms.BODY, b)
                                put(Telephony.Sms.DATE, d)
                                put(Telephony.Sms.TYPE, t)
                                put(Telephony.Sms.READ, rd)
                                put(Telephony.Sms.SEEN, 1)
                            })
                            added++
                        } catch (e: Exception) { skipped++ }
                    }
                    r.endArray()
                } else {
                    r.skipValue()
                }
            }
            r.endObject()
        } finally {
            r.close()
        }
        return "Restore ho gaya: $added naye messages" + (if (skipped > 0) ", $skipped pehle se the" else "")
    }
}
