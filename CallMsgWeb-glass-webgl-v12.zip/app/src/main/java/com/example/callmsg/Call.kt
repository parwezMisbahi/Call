package com.example.callmsg

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.Person
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.telecom.Call
import android.telecom.DisconnectCause
import android.telecom.InCallService
import android.telecom.VideoProfile

// Chalti hui calls ki list + service ka handle (InCallActivity yahin se padhti hai)
object CallHolder {
    val calls = ArrayList<Call>()
    var service: InCallService? = null
    var listener: (() -> Unit)? = null

    // pehle ringing call, warna sabse nayi
    fun primary(): Call? = calls.firstOrNull { it.state == Call.STATE_RINGING } ?: calls.lastOrNull()

    fun numberOf(c: Call): String = c.details?.handle?.schemeSpecificPart ?: ""
}

object CallNotif {
    const val CH = "calls"
    const val ID = 4242

    private fun pi(ctx: Context, act: String, rc: Int): PendingIntent = PendingIntent.getBroadcast(
        ctx, rc, Intent(ctx, CallActionReceiver::class.java).putExtra("act", act),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    @Suppress("DEPRECATION")
    private fun make(ctx: Context, call: Call, name: String, styled: Boolean): Notification {
        val ringing = call.state == Call.STATE_RINGING
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CH)
        else Notification.Builder(ctx).setPriority(Notification.PRIORITY_HIGH)
        b.setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(name)
            .setContentIntent(open)
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (ringing) b.setFullScreenIntent(open, true)
        val started = call.details?.connectTimeMillis ?: 0L
        if (!ringing && started > 0L) b.setShowWhen(true).setWhen(started).setUsesChronometer(true)
        if (styled && Build.VERSION.SDK_INT >= 31) {
            // asli "call" notification: HyperOS ka island / heads-up isi ko call maanta hai
            val who = Person.Builder().setName(name).setImportant(true).build()
            b.setStyle(
                if (ringing) Notification.CallStyle.forIncomingCall(who, pi(ctx, "reject", 1), pi(ctx, "answer", 2))
                else Notification.CallStyle.forOngoingCall(who, pi(ctx, "reject", 3))
            )
        } else if (ringing) {
            b.setContentText("Incoming call")
            b.addAction(Notification.Action.Builder(0, "Decline", pi(ctx, "reject", 1)).build())
            b.addAction(Notification.Action.Builder(0, "Answer", pi(ctx, "answer", 2)).build())
        } else {
            b.setContentText("Ongoing call")
            b.addAction(Notification.Action.Builder(0, "End", pi(ctx, "reject", 3)).build())
        }
        return b.build()
    }

    // Notification ko foreground service bana ke post karo.
    // Android 12+ mein CallStyle tabhi chalta hai jab notification foreground service ki ho
    // (ya fullScreenIntent ho). Ongoing call mein fullScreenIntent nahi hota, isliye pehle
    // yeh fail hoke simple notification ban jaati thi aur Hyper Island mein nahi aati thi.
    private fun post(ctx: Context, n: Notification) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val svc = CallHolder.service
        if (svc != null) {
            try {
                if (Build.VERSION.SDK_INT >= 29) svc.startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL)
                else svc.startForeground(ID, n)
                return
            } catch (e: Exception) { /* neeche normal notify */ }
        }
        nm.notify(ID, n)
    }

    fun show(ctx: Context, call: Call) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel(CH, "Calls", NotificationManager.IMPORTANCE_HIGH)
        )
        val num = CallHolder.numberOf(call)
        val name = if (num.isEmpty()) "Unknown" else SmsHelper.nameFor(ctx, num)
        try {
            post(ctx, make(ctx, call, name, true))
        } catch (e: Exception) {
            // system CallStyle na maane to seedha simple notification
            try { post(ctx, make(ctx, call, name, false)) } catch (e2: Exception) { }
        }
    }

    @Suppress("DEPRECATION")
    fun cancel(ctx: Context) {
        try { CallHolder.service?.stopForeground(true) } catch (e: Exception) { }
        ctx.getSystemService(NotificationManager::class.java).cancel(ID)
    }
}

// Missed call: notification mein "Call back" aur "Message" buttons
object MissedNotif {
    const val CH = "missed"

    @Suppress("DEPRECATION")
    fun show(ctx: Context, number: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel(CH, "Missed calls", NotificationManager.IMPORTANCE_HIGH)
        )
        val name = if (number.isEmpty()) "Private number" else SmsHelper.nameFor(ctx, number)
        val id = 5000 + (Blocklist.norm(number).hashCode() and 0xfff)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(
            ctx, id, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CH)
        else Notification.Builder(ctx).setPriority(Notification.PRIORITY_HIGH)
        b.setSmallIcon(android.R.drawable.sym_call_missed)
            .setContentTitle("Missed call")
            .setContentText(name)
            .setCategory("missed_call")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setShowWhen(true)
        if (number.isNotEmpty()) {
            // activity seedha PendingIntent se: Android 12+ broadcast se activity kholna mana hai
            val callPi = PendingIntent.getActivity(
                ctx, id + 1,
                Intent(Intent.ACTION_CALL, android.net.Uri.parse("tel:" + android.net.Uri.encode(number)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags
            )
            val smsPi = PendingIntent.getActivity(
                ctx, id + 2,
                Intent(ctx, MainActivity::class.java).setData(android.net.Uri.parse("smsto:" + android.net.Uri.encode(number)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags
            )
            b.addAction(Notification.Action.Builder(0, "Call back", callPi).build())
            b.addAction(Notification.Action.Builder(0, "Message", smsPi).build())
        }
        try { nm.notify(id, b.build()) } catch (e: Exception) { }
    }
}

// Notification ke Answer / Decline / End buttons
class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val c = CallHolder.primary() ?: return
        when (intent.getStringExtra("act")) {
            "answer" -> {
                c.answer(VideoProfile.STATE_AUDIO_ONLY)
                ctx.startActivity(
                    Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            else -> if (c.state == Call.STATE_RINGING) c.reject(false, null) else c.disconnect()
        }
    }
}

// System is service ko har call (aane wali / jaane wali) bhejta hai jab hum default Phone app hote hain
class CallService : InCallService() {

    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            if (state != Call.STATE_DISCONNECTED) CallNotif.show(this@CallService, call)
            else if (call.details?.disconnectCause?.code == DisconnectCause.MISSED) {
                MissedNotif.show(this@CallService, CallHolder.numberOf(call))
                AutoReply.onMissedCall(this@CallService, CallHolder.numberOf(call))
            }
            CallHolder.listener?.invoke()
        }
    }

    override fun onCreate() {
        super.onCreate()
        CallHolder.service = this
    }

    override fun onDestroy() {
        if (CallHolder.service === this) CallHolder.service = null
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        // blocked number ki aane wali call: turant reject, na notification na screen
        if (call.state == Call.STATE_RINGING && Blocklist.isBlocked(this, CallHolder.numberOf(call))) {
            try { call.reject(false, null) } catch (e: Exception) { }
            return
        }
        CallHolder.calls.add(call)
        call.registerCallback(cb)
        CallNotif.show(this, call)
        // aane wali call: notification ka full-screen intent screen kholega.
        // jaane wali call: seedha call screen kholo
        if (call.state != Call.STATE_RINGING) {
            try {
                startActivity(Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { }
        }
        CallHolder.listener?.invoke()
    }

    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(cb)
        CallHolder.calls.remove(call)
        val next = CallHolder.primary()
        if (next == null) CallNotif.cancel(this) else CallNotif.show(this, next)
        CallHolder.listener?.invoke()
    }
}
