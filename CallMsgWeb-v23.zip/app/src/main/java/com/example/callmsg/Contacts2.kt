package com.example.callmsg

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import java.io.ByteArrayOutputStream

// ringtone / photo chunte waqt kaunsa contact hai
var pendingContactId = 0L

object ContactTools {
    fun setRingtone(ctx: Context, id: Long, tone: Uri?): String {
        return try {
            val v = ContentValues().apply { put(ContactsContract.Contacts.CUSTOM_RINGTONE, tone?.toString()) }
            val n = ctx.contentResolver.update(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id), v, null, null)
            if (n > 0) "Ringtone set ho gayi" else "Error: ringtone set nahi hui"
        } catch (e: Exception) { "Error: ${e.message}" }
    }

    fun setPhoto(ctx: Context, id: Long, src: Uri): String {
        return try {
            val bmp = ctx.contentResolver.openInputStream(src)?.use { BitmapFactory.decodeStream(it) }
                ?: return "Error: photo nahi khuli"
            val sc = minOf(1f, 720f / maxOf(bmp.width, bmp.height).toFloat())
            val small = if (sc < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true) else bmp
            val bos = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 90, bos)
            var raw = 0L
            ctx.contentResolver.query(
                ContactsContract.RawContacts.CONTENT_URI, arrayOf(ContactsContract.RawContacts._ID),
                ContactsContract.RawContacts.CONTACT_ID + "=?", arrayOf(id.toString()), null
            )?.use { if (it.moveToFirst()) raw = it.getLong(0) }
            if (raw == 0L) return "Error: contact nahi mila"
            val mime = ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE
            val v = ContentValues().apply {
                put(ContactsContract.Data.RAW_CONTACT_ID, raw)
                put(ContactsContract.Data.MIMETYPE, mime)
                put(ContactsContract.CommonDataKinds.Photo.PHOTO, bos.toByteArray())
            }
            val n = ctx.contentResolver.update(
                ContactsContract.Data.CONTENT_URI, v,
                ContactsContract.Data.RAW_CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + "=?",
                arrayOf(raw.toString(), mime)
            )
            if (n == 0) ctx.contentResolver.insert(ContactsContract.Data.CONTENT_URI, v)
            "Photo set ho gayi"
        } catch (e: Exception) { "Error: ${e.message}" }
    }
}
