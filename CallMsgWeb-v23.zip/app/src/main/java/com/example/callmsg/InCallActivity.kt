@file:Suppress("DEPRECATION")

package com.example.callmsg

import android.app.Activity
import android.graphics.Color
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.TelecomManager
import android.telecom.VideoProfile
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// Call screen: ab WebView (incall.html) - main app jaisa glass lens + dialpad wala keypad animation.
// Buttons JS se CallBridge ke through yahin aate hain, state yahan se JS ko push hoti hai.
class InCallActivity : Activity() {

    private lateinit var web: WebView
    private var rec: MediaRecorder? = null
    private val h = Handler(Looper.getMainLooper())
    private var lastNumber = "\u0000"
    private var lastName = ""
    private var ready = false
    private lateinit var dataBridge: Bridge   // contacts / call log (Recent, Contacts se add call ke liye)
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        dataBridge = Bridge(this)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#12141c")) }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            setBackgroundColor(Color.parseColor("#12141c"))
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            addJavascriptInterface(JsApi(), "CallBridge")
            loadUrl("file:///android_asset/incall.html")
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        CallHolder.listener = { refresh() }
        handle(intent)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: android.content.Intent?) {
        if (i?.getStringExtra("act") == "answer") CallHolder.primary()?.answer(VideoProfile.STATE_AUDIO_ONLY)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        CallBubble.inCallVisible = true; CallBubble.sync(this)
        CallHolder.listener = { refresh() }
        h.post(tick)
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        CallBubble.inCallVisible = false; CallBubble.sync(this)
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { rec?.release() } catch (e: Exception) { }
        rec = null
        CallHolder.listener = null
        try { web.removeJavascriptInterface("CallBridge"); web.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // popup / Recent-Contacts page / keypad khula ho to pehle wo band ho, warna call screen background mein
        web.evaluateJavascript("goBack()") { r -> if (r != "true") moveTaskToBack(true) }
    }

    private fun js(code: String) { runOnUiThread { web.evaluateJavascript(code, null) } }

    // JS -> Kotlin. Sab kaam main thread par chalte hain.
    inner class JsApi {
        @JavascriptInterface fun ready() { h.post { ready = true; lastNumber = "\u0000"; refresh() } }
        @JavascriptInterface fun getState(): String = try { buildState()?.toString() ?: "{}" } catch (e: Exception) { "{}" }
        @JavascriptInterface fun answer() { h.post { CallHolder.primary()?.answer(VideoProfile.STATE_AUDIO_ONLY) } }
        @JavascriptInterface fun decline() { h.post { CallHolder.primary()?.reject(false, null) } }
        @JavascriptInterface fun end() { h.post { CallHolder.primary()?.disconnect() } }
        @JavascriptInterface fun mute() {
            h.post {
                val s = CallHolder.service ?: return@post
                s.setMuted(!(s.callAudioState?.isMuted ?: false))
                h.postDelayed({ refresh() }, 150)
            }
        }
        @JavascriptInterface fun speaker() {
            h.post {
                val s = CallHolder.service ?: return@post
                val on = s.callAudioState?.route == CallAudioState.ROUTE_SPEAKER
                s.setAudioRoute(if (on) CallAudioState.ROUTE_EARPIECE else CallAudioState.ROUTE_SPEAKER)
                h.postDelayed({ refresh() }, 150)
            }
        }
        @JavascriptInterface fun hold() {
            h.post {
                val c = CallHolder.primary() ?: return@post
                if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()
                h.postDelayed({ refresh() }, 150)
            }
        }
        // Speaker button: sabhi audio outputs (Earpiece / Speaker / Bluetooth device / Wired headset)
        @JavascriptInterface fun routes(): String = try {
            val st = CallHolder.service?.callAudioState
            val arr = JSONArray()
            if (st != null) {
                val m = st.supportedRouteMask
                fun add(id: String, label: String, on: Boolean, addr: String = "") {
                    arr.put(JSONObject().put("id", id).put("label", label).put("on", on).put("addr", addr))
                }
                if (m and CallAudioState.ROUTE_EARPIECE != 0) add("earpiece", "Earpiece", st.route == CallAudioState.ROUTE_EARPIECE)
                if (m and CallAudioState.ROUTE_WIRED_HEADSET != 0) add("wired", "Wired headset", st.route == CallAudioState.ROUTE_WIRED_HEADSET)
                if (m and CallAudioState.ROUTE_BLUETOOTH != 0) {
                    var added = false
                    if (Build.VERSION.SDK_INT >= 28) {
                        try {
                            val act = st.activeBluetoothDevice
                            for (d in st.supportedBluetoothDevices) {
                                val nm = try { d.name } catch (e: SecurityException) { null }
                                val on = st.route == CallAudioState.ROUTE_BLUETOOTH && (act == null || act.address == d.address)
                                add("bt", if (nm.isNullOrEmpty()) "Bluetooth" else "Bluetooth · $nm", on, d.address ?: "")
                                added = true
                            }
                        } catch (e: Exception) { }
                    }
                    if (!added) add("bt", "Bluetooth", st.route == CallAudioState.ROUTE_BLUETOOTH)
                }
                if (m and CallAudioState.ROUTE_SPEAKER != 0) add("speaker", "Speaker", st.route == CallAudioState.ROUTE_SPEAKER)
            }
            arr.toString()
        } catch (e: Exception) { "[]" }

        @JavascriptInterface fun setRoute(id: String, addr: String) {
            h.post {
                val s = CallHolder.service ?: return@post
                when (id) {
                    "earpiece" -> s.setAudioRoute(CallAudioState.ROUTE_EARPIECE)
                    "wired" -> s.setAudioRoute(CallAudioState.ROUTE_WIRED_HEADSET)
                    "speaker" -> s.setAudioRoute(CallAudioState.ROUTE_SPEAKER)
                    "bt" -> {
                        var done = false
                        if (Build.VERSION.SDK_INT >= 28 && addr.isNotEmpty()) {
                            try {
                                val d = s.callAudioState?.supportedBluetoothDevices?.firstOrNull { it.address == addr }
                                if (d != null) { s.requestBluetoothAudio(d); done = true }
                            } catch (e: Exception) { }
                        }
                        if (!done) s.setAudioRoute(CallAudioState.ROUTE_BLUETOOTH)
                    }
                }
                h.postDelayed({ refresh() }, 250)
            }
        }

        // Add call: chalti call hold hoti hai, naya number usi SIM se lagta hai
        @JavascriptInterface fun addCall(number: String): String {
            val n = number.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
            if (n.isEmpty()) return "Number daalo"
            h.post {
                try {
                    val cur = CallHolder.primary()
                    if (cur != null && cur.state == Call.STATE_ACTIVE && cur.details.can(Call.Details.CAPABILITY_HOLD)) cur.hold()
                    h.postDelayed({
                        try {
                            val tm = getSystemService(TelecomManager::class.java)
                            val ex = Bundle()
                            cur?.details?.accountHandle?.let { ex.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it) }
                            tm.placeCall(Uri.fromParts("tel", n, null), ex)
                        } catch (e: Exception) { js("toast('Call nahi lag paya')") }
                    }, 400)
                } catch (e: Exception) { js("toast('Call nahi lag paya')") }
            }
            return "ok"
        }

        // do calls ho to unhold/hold badalna
        @JavascriptInterface fun swap() {
            h.post {
                val top = CallHolder.topCalls()
                val held = top.firstOrNull { it.state == Call.STATE_HOLDING }
                val active = top.firstOrNull { it.state == Call.STATE_ACTIVE }
                if (held != null) held.unhold() else if (active != null && top.size >= 2) active.hold()
                h.postDelayed({ refresh() }, 300)
            }
        }

        @JavascriptInterface fun merge() {
            h.post {
                val c = CallHolder.primary() ?: return@post
                try {
                    if (c.details.can(Call.Details.CAPABILITY_MERGE_CONFERENCE)) c.mergeConference()
                    else c.conferenceableCalls.firstOrNull()?.let { c.conference(it) }
                } catch (e: Exception) { }
                h.postDelayed({ refresh() }, 300)
            }
        }

        // Recent / Contacts list + wallpaper (main app wala)
        @JavascriptInterface fun getContacts(): String = dataBridge.getContacts()
        @JavascriptInterface fun getCalls(): String = dataBridge.getCalls()
        @JavascriptInterface fun hasPermission(): Boolean = dataBridge.hasPermission()
        @JavascriptInterface fun getBg(): String = dataBridge.getBg()
        @JavascriptInterface fun record() { h.post { toggleRecord() } }
        // Keypad: press par DTMF tone chalta hai, chhodne par ruk jaata hai
        @JavascriptInterface fun dtmfDown(k: String) { h.post { if (k.isNotEmpty()) CallHolder.primary()?.playDtmfTone(k[0]) } }
        @JavascriptInterface fun dtmfUp() { h.post { CallHolder.primary()?.stopDtmfTone() } }
    }

    // Recording: Android 10+ par third-party app ko call ki dono taraf ki awaaz nahi milti.
    // Isliye mic se record hota hai (speaker par dono awaaz aati hain, warna sirf aapki).
    private fun toggleRecord() {
        if (rec != null) { stopRecord(); return }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 77); return
        }
        try {
            val dir = File(getExternalFilesDir(null), "recordings").apply { mkdirs() }
            val num = CallHolder.primary()?.let { CallHolder.numberOf(it) }.orEmpty().filter { it.isDigit() || it == '+' }
            val f = File(dir, "call_${num}_${System.currentTimeMillis()}.m4a")
            rec = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(f.absolutePath)
                prepare(); start()
            }
            android.widget.Toast.makeText(this, "Recording: " + f.name, android.widget.Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            rec = null
            android.widget.Toast.makeText(this, "Recording nahi ho payi", android.widget.Toast.LENGTH_SHORT).show()
        }
        refresh()
    }

    private fun stopRecord() {
        try { rec?.stop() } catch (e: Exception) { }
        try { rec?.release() } catch (e: Exception) { }
        rec = null
        refresh()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (rc == 77 && r.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) toggleRecord()
    }

    private fun simLabel(c: Call): String = try {
        val hd = c.details?.accountHandle
        val tm = getSystemService(TelecomManager::class.java)
        if (hd != null && tm.callCapablePhoneAccounts.size > 1) tm.getPhoneAccount(hd)?.label?.toString().orEmpty() else ""
    } catch (e: Exception) { "" }

    // Call ki poori state JS ke liye
    private fun buildState(): JSONObject? {
        val c = CallHolder.primary() ?: return null
        val num = CallHolder.numberOf(c)
        if (num != lastNumber) {
            lastNumber = num
            lastName = if (num.isEmpty()) "Unknown" else SmsHelper.nameFor(this, num)
        }
        val ringing = c.state == Call.STATE_RINGING
        val stateText = when (c.state) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_DIALING, Call.STATE_CONNECTING, Call.STATE_PULLING_CALL -> "Calling…"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "Call khatam"
            Call.STATE_ACTIVE -> {
                val t = c.details?.connectTimeMillis ?: 0L
                if (t > 0) {
                    val s = ((System.currentTimeMillis() - t) / 1000).coerceAtLeast(0)
                    String.format("%02d:%02d", s / 60, s % 60)
                } else "Connected"
            }
            else -> ""
        }
        val st = CallHolder.service?.callAudioState
        return JSONObject().apply {
            put("name", lastName)
            put("num", if (num.isEmpty() || lastName == num) "" else num)
            put("stateText", stateText)
            put("ringing", ringing)
            put("sim", simLabel(c))
            put("muted", st?.isMuted == true)
            put("spk", st?.route == CallAudioState.ROUTE_SPEAKER)
            put("hold", c.state == Call.STATE_HOLDING)
            put("rec", rec != null)
            put("multi", CallHolder.topCalls().size >= 2)
            val other = CallHolder.topCalls().firstOrNull { it !== c && it.state == Call.STATE_HOLDING }
            put("held", other?.let { o -> CallHolder.numberOf(o).let { n -> if (n.isEmpty()) "Unknown" else SmsHelper.nameFor(this@InCallActivity, n) } } ?: "")
            put("route", when (st?.route) {
                CallAudioState.ROUTE_BLUETOOTH -> "Bluetooth"
                CallAudioState.ROUTE_SPEAKER -> "Speaker"
                CallAudioState.ROUTE_WIRED_HEADSET -> "Headset"
                else -> "Earpiece"
            })
        }
    }

    private fun refresh() {
        val s = buildState()
        if (s == null) { stopRecord(); finish(); return }
        if (ready) web.evaluateJavascript("onState(" + JSONObject.quote(s.toString()) + ")", null)
    }
}
