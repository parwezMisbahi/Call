package com.example.callmsg

import android.content.Context
import org.json.JSONArray

// Block list: poore number ya prefix (jaise 140*). Phone band/restart hone par bhi bachi rehti hai.
object Blocklist {
    private const val PREFS = "callmsg_block"
    private const val KEY = "list"
    private const val KEY_PRIVATE = "private"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // sirf digits; 10 se lambe number ke aakhri 10 digit (country code hatane ke liye)
    fun norm(s: String): String {
        val d = s.filter { it.isDigit() }
        return if (d.length > 10) d.takeLast(10) else d
    }

    fun list(ctx: Context): List<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(sp(ctx).getString(KEY, "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) { }
        return out
    }

    private fun save(ctx: Context, l: List<String>) {
        val a = JSONArray()
        l.forEach { a.put(it) }
        sp(ctx).edit().putString(KEY, a.toString()).apply()
    }

    // entry "140*" = prefix; baaki poora number
    fun add(ctx: Context, raw: String): Boolean {
        val prefix = raw.trim().endsWith("*")
        val d = norm(raw)
        if (d.isEmpty()) return false
        val e = if (prefix) "$d*" else d
        val l = list(ctx).toMutableList()
        if (!l.contains(e)) { l.add(0, e); save(ctx, l) }
        return true
    }

    fun remove(ctx: Context, raw: String) {
        val prefix = raw.trim().endsWith("*")
        val d = norm(raw)
        val e = if (prefix) "$d*" else d
        save(ctx, list(ctx).filter { it != e })
    }

    fun blockPrivate(ctx: Context) = sp(ctx).getBoolean(KEY_PRIVATE, false)
    fun setBlockPrivate(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean(KEY_PRIVATE, v).apply()

    fun isBlocked(ctx: Context, number: String): Boolean {
        val d = norm(number)
        if (d.isEmpty()) return blockPrivate(ctx)
        return list(ctx).any { e ->
            if (e.endsWith("*")) d.startsWith(e.dropLast(1)) else d == e
        }
    }
}
