package com.example.callmsg

import android.content.Context
import android.net.Uri
import android.provider.CallLog
import org.json.JSONArray

// Hidden threads ki list (JS se sync hoti hai) taaki notification mein message ka text na dikhe
object HiddenStore {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("hidden", Context.MODE_PRIVATE)
    fun set(ctx: Context, json: String) { sp(ctx).edit().putString("k", json).apply() }
    fun isHidden(ctx: Context, addr: String): Boolean {
        val d = addr.filter { it.isDigit() }
        val key = if (d.length >= 7) d.takeLast(10) else addr.trim().lowercase()
        try {
            val a = JSONArray(sp(ctx).getString("k", "[]"))
            for (i in 0 until a.length()) if (a.getString(i) == key) return true
        } catch (e: Exception) { }
        return false
    }
}

// Call log ko CSV file mein export
object CallExport {
    private fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    fun write(ctx: Context, uri: Uri): String {
        val os = ctx.contentResolver.openOutputStream(uri, "w") ?: return "Error: file nahi khuli"
        var n = 0
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        os.bufferedWriter().use { w ->
            w.write("number,name,type,date,duration_sec\n")
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION),
                null, null, "date DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val type = when (c.getInt(2)) {
                        1 -> "incoming"; 2 -> "outgoing"; 3 -> "missed"; 5 -> "rejected"; 6 -> "blocked"; else -> "other"
                    }
                    w.write(q(c.getString(0) ?: "") + "," + q(c.getString(1) ?: "") + "," + type + "," +
                        fmt.format(java.util.Date(c.getLong(3))) + "," + c.getLong(4) + "\n")
                    n++
                }
            }
        }
        return "Export ho gaya: $n calls"
    }
}
