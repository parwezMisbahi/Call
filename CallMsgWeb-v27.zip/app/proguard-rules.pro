# WebView JS bridge: R8 inke naam/methods na hataye
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.example.callmsg.Bridge { *; }

# Manifest wale components (Activity/Service/Receiver) aapas ke naam se system bulata hai
-keep class com.example.callmsg.** extends android.app.Activity { *; }
-keep class com.example.callmsg.** extends android.app.Service { *; }
-keep class com.example.callmsg.** extends android.telecom.InCallService { *; }
-keep class com.example.callmsg.** extends android.content.BroadcastReceiver { *; }
-keep class com.example.callmsg.** extends android.appwidget.AppWidgetProvider { *; }

-keepattributes *Annotation*,SourceFile,LineNumberTable
-dontwarn kotlin.**
