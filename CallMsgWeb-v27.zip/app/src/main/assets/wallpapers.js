// Built-in wallpapers: sirf naam yahan; image data wall_<id>.js mein (zaroorat par load hota hai)
window.WSRC=window.WSRC||{};
const WALLS=[{id:"ember",name:"Ember",get src(){return WSRC["ember"]||""}},{id:"gold",name:"Gold",get src(){return WSRC["gold"]||""}},{id:"glass",name:"Glass",get src(){return WSRC["glass"]||""}},{id:"rose",name:"Rose",get src(){return WSRC["rose"]||""}}];
const _wLoaded={};
function loadWall(id){
  if(WSRC[id])return Promise.resolve();
  if(!_wLoaded[id])_wLoaded[id]=new Promise(ok=>{const s=document.createElement('script');s.src='wall_'+id+'.js';s.onload=s.onerror=()=>ok();document.head.appendChild(s)});
  return _wLoaded[id];
}
function loadAllWalls(){return Promise.all(WALLS.map(w=>loadWall(w.id)))}
