package com.example.callmsg

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.CallLog
import android.provider.Telephony
import android.view.View
import android.widget.RemoteViews

// Home-screen glass widget: 4 shortcut + missed calls / unread messages ka count
class CallMsgWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { try { mgr.updateAppWidget(it, build(ctx)) } catch (e: Exception) { } }
    }

    companion object {
        fun refresh(ctx: Context) {
            try {
                val app = ctx.applicationContext
                val mgr = AppWidgetManager.getInstance(app)
                val ids = mgr.getAppWidgetIds(ComponentName(app, CallMsgWidget::class.java))
                if (ids.isEmpty()) return
                val v = build(app)
                ids.forEach { mgr.updateAppWidget(it, v) }
            } catch (e: Exception) { }
        }

        private fun open(ctx: Context, key: String, rc: Int): PendingIntent = PendingIntent.getActivity(
            ctx, rc,
            Intent(ctx, MainActivity::class.java).putExtra("wk", key).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        private fun has(ctx: Context, p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

        private fun missed(ctx: Context): Int {
            if (!has(ctx, Manifest.permission.READ_CALL_LOG)) return -1
            return try {
                ctx.contentResolver.query(
                    CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls._ID),
                    CallLog.Calls.TYPE + "=? AND " + CallLog.Calls.NEW + "=1", arrayOf(CallLog.Calls.MISSED_TYPE.toString()), null
                )?.use { it.count } ?: 0
            } catch (e: Exception) { -1 }
        }

        private fun unread(ctx: Context): Int {
            if (!has(ctx, Manifest.permission.READ_SMS)) return -1
            return try {
                ctx.contentResolver.query(
                    Telephony.Sms.Inbox.CONTENT_URI, arrayOf(Telephony.Sms._ID), Telephony.Sms.READ + "=0", null, null
                )?.use { it.count } ?: 0
            } catch (e: Exception) { -1 }
        }

        fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_glass)
            v.setOnClickPendingIntent(R.id.w_open, open(ctx, "recents", 1))
            v.setOnClickPendingIntent(R.id.w_recents, open(ctx, "recents", 2))
            v.setOnClickPendingIntent(R.id.w_contacts, open(ctx, "contacts", 3))
            v.setOnClickPendingIntent(R.id.w_msgs, open(ctx, "messages", 4))
            v.setOnClickPendingIntent(R.id.w_dial, open(ctx, "dial", 5))
            val m = missed(ctx); val u = unread(ctx)
            if (m < 0 && u < 0) {
                v.setTextViewText(R.id.w_info, "App kholke permission do")
                v.setViewVisibility(R.id.w_badge, View.GONE)
            } else {
                val parts = ArrayList<String>()
                if (m > 0) parts.add("$m missed call" + if (m > 1) "s" else "")
                if (u > 0) parts.add("$u unread")
                v.setTextViewText(R.id.w_info, if (parts.isEmpty()) "Sab clear \u2713" else parts.joinToString(" \u00B7 "))
                val total = maxOf(m, 0) + maxOf(u, 0)
                if (total > 0) { v.setTextViewText(R.id.w_badge, if (total > 99) "99+" else total.toString()); v.setViewVisibility(R.id.w_badge, View.VISIBLE) }
                else v.setViewVisibility(R.id.w_badge, View.GONE)
            }
            return v
        }
    }
}
