package com.example.callmsg

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Person
import android.app.role.RoleManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SmsManager
import org.json.JSONObject

object SmsHelper {
    const val CH_SMS = "sms"
    const val ACT_SENT = "com.example.callmsg.SMS_SENT"
    const val ACT_DLV = "com.example.callmsg.SMS_DELIVERED"

    // bheje hue message ka haal: p = sending, s = sent, d = delivered, f = failed (key = message ki date)
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("smsst", Context.MODE_PRIVATE)

    fun setStatus(ctx: Context, d: Long, v: String) {
        val p = prefs(ctx)
        val e = p.edit()
        e.putString(d.toString(), v)
        val keys = p.all.keys
        if (keys.size > 300) {
            keys.mapNotNull { it.toLongOrNull() }.sorted().take(keys.size - 250).forEach { e.remove(it.toString()) }
        }
        e.apply()
    }

    fun getStatus(ctx: Context, d: Long): String = prefs(ctx).getString(d.toString(), "") ?: ""

    fun statusJson(ctx: Context): String {
        val o = JSONObject()
        for ((k, v) in prefs(ctx).all) o.put(k, v.toString())
        return o.toString()
    }

    // 3 tarah se check: kuch phones (MIUI / HyperOS) par ek tareeka galat jawab deta hai
    fun isDefaultSms(ctx: Context): Boolean {
        try { if (Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName) return true } catch (e: Exception) { }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = ctx.getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleHeld(RoleManager.ROLE_SMS)) return true
            }
        } catch (e: Exception) { }
        try { if (Settings.Secure.getString(ctx.contentResolver, "sms_default_application") == ctx.packageName) return true } catch (e: Exception) { }
        return false
    }

    @Suppress("DEPRECATION")
    fun send(ctx: Context, to: String, text: String, d: Long = System.currentTimeMillis()) {
        val sm: SmsManager =
            if ((Build.VERSION.SDK_INT >= 31)) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        val parts = sm.divideMessage(text)
        val sent = ArrayList<PendingIntent>()
        val dlv = ArrayList<PendingIntent>()
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        for (i in 0 until parts.size) {
            val rc = (d % 500000000L).toInt() * 4 + i
            sent.add(PendingIntent.getBroadcast(ctx, rc,
                Intent(ctx, SmsStatusReceiver::class.java).setAction(ACT_SENT).putExtra("d", d), flags))
            dlv.add(PendingIntent.getBroadcast(ctx, rc,
                Intent(ctx, SmsStatusReceiver::class.java).setAction(ACT_DLV).putExtra("d", d), flags))
        }
        setStatus(ctx, d, "p")
        sm.sendMultipartTextMessage(to, null, parts, sent, dlv)
        // default SMS app ko apna bheja hua message khud provider mein likhna padta hai
        if (isDefaultSms(ctx)) {
            try {
                ctx.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, ContentValues().apply {
                    put(Telephony.Sms.ADDRESS, to)
                    put(Telephony.Sms.BODY, text)
                    put(Telephony.Sms.DATE, d)
                    put(Telephony.Sms.READ, 1)
                    put(Telephony.Sms.SEEN, 1)
                })
            } catch (e: Exception) { }
        }
    }

    fun nameFor(ctx: Context, number: String): String {
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) return it.getString(0) ?: number }
        } catch (e: Exception) { }
        return number
    }

    fun notify(ctx: Context, addr: String, body0: String) {
        CallMsgWidget.refresh(ctx)
        val hidden = HiddenStore.isHidden(ctx, addr)
        val body = if (hidden) "Hidden message" else body0
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if ((Build.VERSION.SDK_INT >= 26)) nm.createNotificationChannel(
            NotificationChannel(CH_SMS, "Messages", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = Intent(ctx, MainActivity::class.java)
            .setAction(Intent.ACTION_SENDTO)
            .setData(Uri.parse("smsto:" + Uri.encode(addr)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            ctx, addr.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val b = if ((Build.VERSION.SDK_INT >= 26)) android.app.Notification.Builder(ctx, CH_SMS)
        else android.app.Notification.Builder(ctx).setPriority(android.app.Notification.PRIORITY_HIGH)
        val who = if (hidden) "New message" else nameFor(ctx, addr)
        b.setSmallIcon(android.R.drawable.sym_action_email)
            .setContentTitle(who)
            .setContentText(body)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setShowWhen(true)
            .setWhen(System.currentTimeMillis())
            .setCategory(android.app.Notification.CATEGORY_MESSAGE)
        // asli "message" notification (MessagingStyle): HyperOS / One UI ise island / heads-up mein alag pehchaante hain
        if (Build.VERSION.SDK_INT >= 28) {
            val me = Person.Builder().setName("You").build()
            val from = Person.Builder().setName(who).build()
            b.setStyle(android.app.Notification.MessagingStyle(me).addMessage(body, System.currentTimeMillis(), from))
        } else {
            b.setStyle(android.app.Notification.BigTextStyle().bigText(body))
        }
        // OTP wala message: notification mein seedha "Copy" button
        val otp = Otp.find(body)
        if (otp != null) {
            val cp = PendingIntent.getBroadcast(
                ctx, addr.hashCode() + 7, Intent(ctx, OtpCopyReceiver::class.java).putExtra("code", otp),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            b.addAction(android.app.Notification.Action.Builder(0, "Copy $otp", cp).build())
        }
        // Quick reply: notification se hi jawab likho
        if (Build.VERSION.SDK_INT >= 24 && !hidden && addr.any { it.isDigit() }) {
            val ri = android.app.RemoteInput.Builder("reply").setLabel("Reply").build()
            val rpi = PendingIntent.getBroadcast(
                ctx, addr.hashCode() + 9, Intent(ctx, QuickReplyReceiver::class.java).putExtra("addr", addr),
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            )
            b.addAction(android.app.Notification.Action.Builder(0, "Reply", rpi).addRemoteInput(ri).build())
        }
        try { nm.notify(addr.hashCode(), b.build()) } catch (e: Exception) { }
    }
}

class QuickReplyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val addr = intent.getStringExtra("addr") ?: return
        val txt = android.app.RemoteInput.getResultsFromIntent(intent)?.getCharSequence("reply")?.toString()?.trim().orEmpty()
        if (txt.isNotEmpty()) try { SmsHelper.send(ctx, addr, txt) } catch (e: Exception) { }
        ctx.getSystemService(NotificationManager::class.java).cancel(addr.hashCode())
    }
}

// Message gaya / fail hua / deliver hua: yahan pata chalta hai
class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val d = intent.getLongExtra("d", 0L)
        if (d == 0L) return
        val ok = resultCode == Activity.RESULT_OK
        val cur = SmsHelper.getStatus(ctx, d)
        if (intent.action == SmsHelper.ACT_DLV) {
            if (ok) SmsHelper.setStatus(ctx, d, "d")
            return
        }
        if (ok) {
            if (cur != "f" && cur != "d") SmsHelper.setStatus(ctx, d, "s")
        } else {
            SmsHelper.setStatus(ctx, d, "f")
        }
        if (SmsHelper.isDefaultSms(ctx)) {
            try {
                val v = ContentValues().apply { put(Telephony.Sms.TYPE, if (ok) 2 else 5) }
                if (ok) ctx.contentResolver.update(Telephony.Sms.CONTENT_URI, v, "date=? AND type IN (2,4,6)", arrayOf(d.toString()))
                else ctx.contentResolver.update(Telephony.Sms.CONTENT_URI, v, "date=? AND type IN (2,4,5,6)", arrayOf(d.toString()))
            } catch (e: Exception) { }
        }
    }
}

// Naya SMS aaya: sirf default SMS app ko yeh broadcast milta hai, isliye inbox mein likhna hamara kaam hai
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (msgs.isEmpty()) return
        val addr = msgs[0].originatingAddress ?: ""
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        try {
            ctx.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
                put(Telephony.Sms.ADDRESS, addr)
                put(Telephony.Sms.BODY, body)
                put(Telephony.Sms.DATE, System.currentTimeMillis())
                put(Telephony.Sms.DATE_SENT, msgs[0].timestampMillis)
                put(Telephony.Sms.READ, 0)
                put(Telephony.Sms.SEEN, 0)
                put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_INBOX)
            })
        } catch (e: Exception) { }
        SmsHelper.notify(ctx, addr, body)
        AutoReply.onSms(ctx, addr)
    }
}

// MMS: default SMS app banne ke liye receiver hona zaroori hai (MMS abhi support nahi)
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) { }
}

// Call aane par "Message bhejo" quick reply
class RespondViaMessageService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val num = intent?.data?.schemeSpecificPart?.substringBefore('?')?.let { Uri.decode(it) }
            val text = intent?.getStringExtra(Intent.EXTRA_TEXT)
            if (!num.isNullOrEmpty() && !text.isNullOrEmpty()) SmsHelper.send(this, num, text)
        } catch (e: Exception) { }
        stopSelf(startId)
        return START_NOT_STICKY
    }
}
