package com.example.callmsg

import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.provider.Telephony
import android.telecom.Call
import android.telecom.CallAudioState
import android.util.Base64
import android.util.Xml
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream

// SMS backup XML mein ("SMS Backup & Restore" jaisa format)
object BackupXml {
    fun write(ctx: Context, uri: Uri): String {
        val os = ctx.contentResolver.openOutputStream(uri, "w") ?: return "Error: file nahi khuli"
        var n = 0
        os.use {
            val cur = ctx.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.READ),
                null, null, "date ASC"
            ) ?: return "Error: SMS nahi padh paya"
            cur.use { c ->
                val x = Xml.newSerializer()
                x.setOutput(it, "UTF-8")
                x.startDocument("UTF-8", true)
                x.startTag(null, "smses"); x.attribute(null, "count", c.count.toString())
                while (c.moveToNext()) {
                    x.startTag(null, "sms")
                    x.attribute(null, "protocol", "0")
                    x.attribute(null, "address", c.getString(0) ?: "")
                    x.attribute(null, "date", c.getLong(2).toString())
                    x.attribute(null, "type", c.getInt(3).toString())
                    x.attribute(null, "body", (c.getString(1) ?: "").replace(Regex("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F]"), ""))
                    x.attribute(null, "read", c.getInt(4).toString())
                    x.endTag(null, "sms")
                    n++
                }
                x.endTag(null, "smses")
                x.endDocument()
            }
        }
        return "XML backup ho gaya: $n messages"
    }

    fun read(ctx: Context, uri: Uri): String {
        val have = HashSet<String>()
        ctx.contentResolver.query(
            Telephony.Sms.CONTENT_URI, arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE), null, null, null
        )?.use { c -> while (c.moveToNext()) have.add("${c.getLong(2)}|${c.getString(0)}|${(c.getString(1) ?: "").hashCode()}") }
        var added = 0; var skipped = 0
        val ins = ctx.contentResolver.openInputStream(uri) ?: return "Error: file nahi khuli"
        ins.use {
            val p = Xml.newPullParser()
            p.setInput(it, "UTF-8")
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name == "sms") {
                    val a = p.getAttributeValue(null, "address") ?: ""
                    val b = p.getAttributeValue(null, "body") ?: ""
                    val d = p.getAttributeValue(null, "date")?.toLongOrNull() ?: 0L
                    val t = p.getAttributeValue(null, "type")?.toIntOrNull() ?: 1
                    val rd = p.getAttributeValue(null, "read")?.toIntOrNull() ?: 1
                    if (!have.add("$d|$a|${b.hashCode()}")) skipped++
                    else try {
                        ctx.contentResolver.insert(Telephony.Sms.CONTENT_URI, ContentValues().apply {
                            put(Telephony.Sms.ADDRESS, a); put(Telephony.Sms.BODY, b); put(Telephony.Sms.DATE, d)
                            put(Telephony.Sms.TYPE, t); put(Telephony.Sms.READ, rd); put(Telephony.Sms.SEEN, 1)
                        })
                        added++
                    } catch (e: Exception) { skipped++ }
                }
                ev = p.next()
            }
        }
        return "Restore ho gaya: $added naye messages" + (if (skipped > 0) ", $skipped pehle se the" else "")
    }
}

// Pehle se phone mein maujood MMS (text + photo) padhna. Bhejna / download karna abhi nahi hai.
object MmsReader {
    fun query(ctx: Context): JSONArray {
        val out = JSONArray()
        try {
            ctx.contentResolver.query(Uri.parse("content://mms"), arrayOf("_id", "date", "msg_box"), null, null, "date DESC")?.use { c ->
                while (c.moveToNext() && out.length() < 150) {
                    val id = c.getLong(0); val box = c.getInt(2)
                    var addr = ""
                    ctx.contentResolver.query(Uri.parse("content://mms/$id/addr"), arrayOf("address", "type"), null, null, null)?.use { a ->
                        while (a.moveToNext()) {
                            val ad = a.getString(0) ?: ""; val t = a.getInt(1)
                            if (ad.contains("insert-address-token")) continue
                            if ((box == 1 && t == 137) || (box != 1 && t == 151)) { addr = ad; break }
                        }
                    }
                    var text = ""; var img = 0L
                    ctx.contentResolver.query(Uri.parse("content://mms/part"), arrayOf("_id", "ct", "text"), "mid=?", arrayOf(id.toString()), null)?.use { p ->
                        while (p.moveToNext()) {
                            val ct = p.getString(1) ?: ""
                            if (ct == "text/plain") text += (p.getString(2) ?: "")
                            else if (ct.startsWith("image/") && img == 0L) img = p.getLong(0)
                        }
                    }
                    if (addr.isEmpty()) continue
                    val o = JSONObject().put("a", addr).put("b", if (text.isEmpty() && img != 0L) "Photo" else text)
                        .put("d", c.getLong(1) * 1000).put("s", box != 1).put("mm", true)
                    if (img != 0L) o.put("pi", img)
                    out.put(o)
                }
            }
        } catch (e: Exception) { }
        return out
    }

    fun image(ctx: Context, part: Long): String = try {
        val u = Uri.parse("content://mms/part/$part")
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / s > 1280 || o.outHeight / s > 1280) s *= 2
        val bmp = ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }
        if (bmp == null) "" else {
            val sc = minOf(1f, 640f / maxOf(bmp.width, bmp.height).toFloat())
            val sm = if (sc < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true) else bmp
            val bos = ByteArrayOutputStream()
            sm.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        }
    } catch (e: Exception) { "" }
}

// Floating call bubble: call chal rahi ho aur app saamne na ho to glass pill dikhti hai (naam · time, speaker, call kaato)
object CallBubble {
    @Volatile var inCallVisible = false
    private var root: LinearLayout? = null
    private var label: TextView? = null
    private var spk: ImageView? = null
    private var appCtx: Context? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { update(); h.postDelayed(this, 1000) } }

    private fun sp(ctx: Context) = ctx.getSharedPreferences("bubble", Context.MODE_PRIVATE)
    fun enabled(ctx: Context) = sp(ctx).getBoolean("on", false)
    fun setEnabled(ctx: Context, v: Boolean) { sp(ctx).edit().putBoolean("on", v).apply(); sync(ctx) }
    fun canDraw(ctx: Context) = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)
    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun sync(ctx: Context) {
        val app = ctx.applicationContext
        h.post {
            val c = CallHolder.primary()
            val show = enabled(app) && canDraw(app) && !inCallVisible && c != null &&
                c.state != Call.STATE_RINGING && c.state != Call.STATE_DISCONNECTED
            if (show) showView(app) else hide()
        }
    }

    private fun hide() {
        h.removeCallbacks(tick)
        val v = root ?: return
        try { (appCtx?.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) { }
        root = null; label = null; spk = null
    }

    private fun speakerOn() = CallHolder.service?.callAudioState?.route == CallAudioState.ROUTE_SPEAKER

    private fun paintSpk() {
        val b = spk ?: return
        val on = speakerOn()
        (b.background as? GradientDrawable)?.setColor(if (on) Color.parseColor("#F2FFFFFF") else Color.parseColor("#33FFFFFF"))
        if (on) b.setColorFilter(Color.parseColor("#111111"), PorterDuff.Mode.SRC_IN) else b.clearColorFilter()
    }

    private fun update() {
        val tv = label ?: return
        val ctx = appCtx ?: return
        val c = CallHolder.primary() ?: return
        val num = CallHolder.numberOf(c)
        val name = if (num.isEmpty()) "Unknown" else SmsHelper.nameFor(ctx, num)
        val t = c.details?.connectTimeMillis ?: 0L
        val st = when {
            c.state == Call.STATE_HOLDING -> "On hold"
            c.state == Call.STATE_ACTIVE && t > 0 -> { val s = ((System.currentTimeMillis() - t) / 1000).coerceAtLeast(0); String.format("%02d:%02d", s / 60, s % 60) }
            else -> "Calling…"
        }
        tv.text = "$name · $st"
        paintSpk()
    }

    private fun circle(ctx: Context, icon: Int, fill: Int, desc: String): ImageView = ImageView(ctx).apply {
        setImageResource(icon)
        contentDescription = desc
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(ctx, 7), dp(ctx, 7), dp(ctx, 7), dp(ctx, 7))
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(fill) }
        layoutParams = LinearLayout.LayoutParams(dp(ctx, 38), dp(ctx, 38)).apply { leftMargin = dp(ctx, 6) }
    }

    private fun glass(ctx: Context): LayerDrawable {
        val r = dp(ctx, 28).toFloat()
        val body = GradientDrawable().apply { cornerRadius = r; setColor(Color.parseColor("#59141826")); setStroke(dp(ctx, 1), Color.parseColor("#99FFFFFF")) }
        val shine = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#4DFFFFFF"), Color.parseColor("#00FFFFFF"), Color.parseColor("#1FFFC8DC")))
            .apply { cornerRadius = r }
        return LayerDrawable(arrayOf(body, shine))
    }

    private fun showView(ctx: Context) {
        if (root != null) return
        appCtx = ctx
        try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(ctx, 16), dp(ctx, 6), dp(ctx, 6), dp(ctx, 6))
                background = glass(ctx)
            }
            val tv = TextView(ctx).apply {
                setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
                setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END
                maxWidth = dp(ctx, 170)
                setShadowLayer(3f, 0f, 1f, Color.parseColor("#88000000"))
            }
            val sb = circle(ctx, R.drawable.ic_bubble_speaker, Color.parseColor("#33FFFFFF"), "Speaker")
            val eb = circle(ctx, R.drawable.ic_bubble_end, Color.parseColor("#F2E5382E"), "End call")
            box.addView(tv); box.addView(sb); box.addView(eb)
            sb.setOnClickListener {
                val s = CallHolder.service ?: return@setOnClickListener
                s.setAudioRoute(if (speakerOn()) CallAudioState.ROUTE_EARPIECE else CallAudioState.ROUTE_SPEAKER)
                h.postDelayed({ paintSpk() }, 200)
            }
            eb.setOnClickListener {
                try { CallHolder.primary()?.disconnect() } catch (e: Exception) { }
                sync(ctx)
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(ctx, 16); y = dp(ctx, 80) }
            // NOTE: FLAG_BLUR_BEHIND yahan nahi lagana: wo sirf pill nahi, poori screen blur kar deta hai
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            box.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx; val dy = e.rawY - sy
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                        lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) { }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        try { ctx.startActivity(Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (ex: Exception) { }
                    }
                }
                true
            }
            wm.addView(box, lp)
            root = box; label = tv; spk = sb
            update()
            h.postDelayed(tick, 1000)
        } catch (e: Exception) { root = null; label = null; spk = null }
    }
}
