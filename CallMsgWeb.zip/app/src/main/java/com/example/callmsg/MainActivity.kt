package com.example.callmsg

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.SmsManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

val PERMS = arrayOf(
    Manifest.permission.CALL_PHONE,
    Manifest.permission.READ_CONTACTS,
    Manifest.permission.READ_SMS,
    Manifest.permission.SEND_SMS,
    Manifest.permission.RECEIVE_SMS
)

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        web.evaluateJavascript("onPermissionResult()", null)
    }
}

// JavaScript se yeh functions Android.xxx() naam se call hote hain
class Bridge(private val act: Activity) {

    private fun granted() = PERMS.all {
        act.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    @JavascriptInterface
    fun hasPermission(): Boolean = granted()

    @JavascriptInterface
    fun requestPermission() {
        act.runOnUiThread { act.requestPermissions(PERMS, 1) }
    }

    @JavascriptInterface
    fun getContacts(): String {
        val arr = JSONArray()
        if (!granted()) return arr.toString()
        try {
            val name = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            val num = ContactsContract.CommonDataKinds.Phone.NUMBER
            act.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(name, num), null, null, "$name ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    arr.put(JSONObject().put("n", c.getString(0) ?: "").put("p", c.getString(1) ?: ""))
                }
            }
        } catch (e: Exception) { }
        return arr.toString()
    }

    @JavascriptInterface
    fun getSms(): String {
        val arr = JSONArray()
        if (!granted()) return arr.toString()
        try {
            act.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE),
                null, null, "date DESC"
            )?.use { c ->
                while (c.moveToNext() && arr.length() < 300) {
                    arr.put(
                        JSONObject()
                            .put("a", c.getString(0) ?: "")
                            .put("b", c.getString(1) ?: "")
                            .put("d", c.getLong(2))
                            .put("s", c.getInt(3) == Telephony.Sms.MESSAGE_TYPE_SENT)
                    )
                }
            }
        } catch (e: Exception) { }
        return arr.toString()
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) act.getSystemService(SmsManager::class.java)
        else SmsManager.getDefault()

    @JavascriptInterface
    fun sendSms(to: String, text: String): String = try {
        val sm = smsManager()
        sm.sendMultipartTextMessage(to, null, sm.divideMessage(text), null, null)
        "ok"
    } catch (e: Exception) {
        "Error: ${e.message}"
    }

    @JavascriptInterface
    fun call(number: String): String = try {
        act.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
        "ok"
    } catch (e: Exception) {
        "Error: ${e.message}"
    }
}
