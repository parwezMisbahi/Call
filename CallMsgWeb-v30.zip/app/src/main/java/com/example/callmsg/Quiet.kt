package com.example.callmsg

import android.app.PendingIntent
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import org.json.JSONObject
import java.util.Calendar

// ---------- Quiet time: fixed time mein aane wali call reject + SMS chala jaye ----------
object QuietTime {
    private const val DEF = "Main abhi available nahi hoon, thodi der mein baat karta hoon."
    private fun sp(ctx: Context) = ctx.getSharedPreferences("quiet", Context.MODE_PRIVATE)

    fun get(ctx: Context): JSONObject {
        val p = sp(ctx)
        return JSONObject()
            .put("on", p.getBoolean("on", false))
            .put("start", p.getInt("start", 22 * 60))
            .put("end", p.getInt("end", 7 * 60))
            .put("msg", p.getString("msg", DEF) ?: DEF)
            .put("sms", p.getBoolean("sms", true))
    }

    fun set(ctx: Context, o: JSONObject) {
        sp(ctx).edit()
            .putBoolean("on", o.optBoolean("on"))
            .putInt("start", o.optInt("start", 22 * 60).coerceIn(0, 1439))
            .putInt("end", o.optInt("end", 7 * 60).coerceIn(0, 1439))
            .putString("msg", o.optString("msg").trim())
            .putBoolean("sms", o.optBoolean("sms", true))
            .apply()
        try { TileService.requestListeningState(ctx, ComponentName(ctx, QuietTile::class.java)) } catch (e: Exception) { }
    }

    fun isOn(ctx: Context) = sp(ctx).getBoolean("on", false)

    fun setOn(ctx: Context, v: Boolean) {
        sp(ctx).edit().putBoolean("on", v).apply()
        try { TileService.requestListeningState(ctx, ComponentName(ctx, QuietTile::class.java)) } catch (e: Exception) { }
    }

    // abhi ka time [start, end) ke andar hai? (raat paar karne wala window bhi chalta hai, jaise 22:00 -> 07:00)
    fun inWindow(ctx: Context): Boolean {
        val p = sp(ctx)
        val s = p.getInt("start", 22 * 60); val e = p.getInt("end", 7 * 60)
        val c = Calendar.getInstance(); val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return when {
            s == e -> true            // start = end: poora din
            s < e -> now in s until e
            else -> now >= s || now < e
        }
    }

    fun active(ctx: Context) = isOn(ctx) && inWindow(ctx)

    fun label(ctx: Context): String {
        val p = sp(ctx)
        fun f(m: Int): String { val h = m / 60; val mm = m % 60; val h12 = if (h % 12 == 0) 12 else h % 12; return String.format("%d:%02d %s", h12, mm, if (h < 12) "AM" else "PM") }
        return f(p.getInt("start", 22 * 60)) + " – " + f(p.getInt("end", 7 * 60))
    }

    // ek hi number ko 10 minute mein ek hi SMS (baar-baar call par spam na ho)
    fun sendSms(ctx: Context, num: String) {
        val p = sp(ctx)
        if (!p.getBoolean("sms", true)) return
        val msg = (p.getString("msg", DEF) ?: "").trim()
        if (msg.isEmpty()) return
        if (num.any { it.isLetter() } || num.count { it.isDigit() } < 10) return
        val key = "last_" + Blocklist.norm(num)
        val now = System.currentTimeMillis()
        if (now - p.getLong(key, 0L) < 600000L) return
        val e = p.edit()
        for ((k, v) in p.all) if (k.startsWith("last_") && v is Long && now - v > 600000L) e.remove(k)
        e.putLong(key, now).apply()
        try { SmsHelper.send(ctx, num, msg) } catch (ex: Exception) { }
    }

    fun requestAddTile(ctx: Context): String {
        if (Build.VERSION.SDK_INT < 33) return "Status bar neeche kheencho → Edit → 'Quiet time' tile add karo"
        return try {
            val sm = ctx.getSystemService(StatusBarManager::class.java)
            sm.requestAddTileService(
                ComponentName(ctx, QuietTile::class.java), "Quiet time",
                Icon.createWithResource(ctx, R.drawable.ic_qt), ctx.mainExecutor
            ) { }
            "ok"
        } catch (e: Exception) { "Status bar neeche kheencho → Edit → 'Quiet time' tile add karo" }
    }
}

// Status bar (Quick Settings) ka tile: ek tap = Quiet time On / Off
class QuietTile : TileService() {
    override fun onStartListening() { paint() }
    override fun onClick() {
        val run = { QuietTime.setOn(this, !QuietTime.isOn(this)); paint() }
        if (isLocked) unlockAndRun { run() } else run()
    }
    private fun paint() {
        val t = qsTile ?: return
        val on = QuietTime.isOn(this)
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Quiet time"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (on) QuietTime.label(this) else "Off"
        t.icon = Icon.createWithResource(this, R.drawable.ic_qt)
        t.updateTile()
    }
}

// ---------- Home screen par kisi number ka shortcut (call / message) ----------
object HomeShortcut {
    private fun icon(name: String): Icon {
        val s = 216
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val hue = ((name.hashCode() and 0x7fffffff) % 360).toFloat()
        c.drawColor(Color.HSVToColor(floatArrayOf(hue, .55f, .78f)))
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 92f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        }
        val ch = Character.toUpperCase(name.trim().firstOrNull { it.isLetterOrDigit() } ?: '#').toString()
        c.drawText(ch, s / 2f, s / 2f - (p.descent() + p.ascent()) / 2f, p)
        return if (Build.VERSION.SDK_INT >= 26) Icon.createWithAdaptiveBitmap(bmp) else Icon.createWithBitmap(bmp)
    }

    fun pin(ctx: Context, kind: String, num: String, name: String): String {
        if (Build.VERSION.SDK_INT < 26) return "Is Android version par shortcut nahi ban sakta"
        val n = num.replace(Regex("[^\\d+]"), "")
        if (n.isEmpty()) return "Number nahi hai"
        val sm = ctx.getSystemService(ShortcutManager::class.java) ?: return "Shortcut support nahi hai"
        if (!sm.isRequestPinShortcutSupported) return "Aapka launcher home-screen shortcut support nahi karta"
        val label = name.ifBlank { num }
        val call = kind == "call"
        val intent = if (call) Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n)))
        else Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).setClass(ctx, MainActivity::class.java)
        val info = ShortcutInfo.Builder(ctx, (if (call) "c_" else "m_") + n)
            .setShortLabel(if (call) label else "SMS $label")
            .setLongLabel(if (call) "Call $label" else "Message $label")
            .setIcon(icon(label))
            .setIntent(intent)
            .build()
        return try { if (sm.requestPinShortcut(info, null)) "ok" else "Shortcut nahi ban paya" } catch (e: Exception) { "Error: ${e.message}" }
    }
}
