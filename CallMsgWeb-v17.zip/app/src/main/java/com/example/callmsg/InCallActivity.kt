@file:Suppress("DEPRECATION")

package com.example.callmsg

import android.app.Activity
import android.app.AlertDialog
import android.view.MotionEvent
import android.media.MediaRecorder
import android.telecom.TelecomManager
import java.io.File
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

// Call screen: naam, number, timer, Answer / Decline, Mute, Speaker, End
class InCallActivity : Activity() {

    private lateinit var nameTv: TextView
    private lateinit var numTv: TextView
    private lateinit var stateTv: TextView
    private lateinit var answerBtn: Button
    private lateinit var declineBtn: Button
    private lateinit var endBtn: Button
    private lateinit var muteBtn: Button
    private lateinit var spkBtn: Button
    private lateinit var holdBtn: Button
    private lateinit var keyBtn: Button
    private lateinit var mergeBtn: Button
    private lateinit var routeBtn: Button
    private lateinit var recBtn: Button
    private lateinit var simTv: TextView
    private var rec: MediaRecorder? = null
    private lateinit var ongoingRow: LinearLayout
    private lateinit var ringRow: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private var lastNumber = "\u0000"
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(text: String, color: Int): Button = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 16f
        isAllCaps = false
        background = GradientDrawable().apply { cornerRadius = dp(40).toFloat(); setColor(color) }
        layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f).apply { setMargins(dp(8), 0, dp(8), 0) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        } else {
                window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#12141c"))
            setPadding(dp(16), dp(72), dp(16), dp(40))
        }
        nameTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 32f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }
        numTv = TextView(this).apply { setTextColor(Color.parseColor("#aab0c0")); textSize = 16f; gravity = Gravity.CENTER }
        stateTv = TextView(this).apply {
            setTextColor(Color.parseColor("#7fd1a0")); textSize = 18f; gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }
        simTv = TextView(this).apply {
            setTextColor(Color.parseColor("#aab0c0")); textSize = 14f; gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        }
        val spacer = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, 0, 1f) }

        answerBtn = btn("Answer", Color.parseColor("#2e9e5b")).apply {
            setOnClickListener { CallHolder.primary()?.answer(VideoProfile.STATE_AUDIO_ONLY) }
        }
        declineBtn = btn("Decline", Color.parseColor("#d0443a")).apply {
            setOnClickListener { CallHolder.primary()?.reject(false, null) }
        }
        ringRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; addView(declineBtn); addView(answerBtn)
        }

        muteBtn = btn("Mute", Color.parseColor("#2b2f3d")).apply {
            setOnClickListener {
                val s = CallHolder.service ?: return@setOnClickListener
                s.setMuted(!(s.callAudioState?.isMuted ?: false))
                h.postDelayed({ refresh() }, 150)
            }
        }
        spkBtn = btn("Speaker", Color.parseColor("#2b2f3d")).apply {
            setOnClickListener {
                val s = CallHolder.service ?: return@setOnClickListener
                val on = s.callAudioState?.route == CallAudioState.ROUTE_SPEAKER
                s.setAudioRoute(if (on) CallAudioState.ROUTE_EARPIECE else CallAudioState.ROUTE_SPEAKER)
                h.postDelayed({ refresh() }, 150)
            }
        }
        holdBtn = btn("Hold", Color.parseColor("#2b2f3d")).apply {
            setOnClickListener {
                val c = CallHolder.primary() ?: return@setOnClickListener
                if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()
                h.postDelayed({ refresh() }, 150)
            }
        }
        keyBtn = btn("Keypad", Color.parseColor("#2b2f3d")).apply { setOnClickListener { showKeypad() } }
        mergeBtn = btn("Merge", Color.parseColor("#2b2f3d")).apply {
            setOnClickListener {
                val c = CallHolder.primary() ?: return@setOnClickListener
                try {
                    if (c.details.can(Call.Details.CAPABILITY_MERGE_CONFERENCE)) c.mergeConference()
                    else c.conferenceableCalls.firstOrNull()?.let { c.conference(it) }
                } catch (e: Exception) { }
                h.postDelayed({ refresh() }, 300)
            }
        }
        routeBtn = btn("Earpiece", Color.parseColor("#2b2f3d")).apply {
            setOnClickListener {
                val s = CallHolder.service ?: return@setOnClickListener
                val st = s.callAudioState ?: return@setOnClickListener
                val order = intArrayOf(
                    CallAudioState.ROUTE_EARPIECE, CallAudioState.ROUTE_WIRED_HEADSET,
                    CallAudioState.ROUTE_BLUETOOTH, CallAudioState.ROUTE_SPEAKER
                ).filter { st.supportedRouteMask and it != 0 }
                if (order.isEmpty()) return@setOnClickListener
                val i = order.indexOf(st.route)
                s.setAudioRoute(order[(i + 1) % order.size])
                h.postDelayed({ refresh() }, 200)
            }
        }
        recBtn = btn("Record", Color.parseColor("#2b2f3d")).apply { setOnClickListener { toggleRecord() } }
        endBtn = btn("End call", Color.parseColor("#d0443a")).apply {
            setOnClickListener { CallHolder.primary()?.disconnect() }
        }
        ongoingRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val top = LinearLayout(this@InCallActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(muteBtn); addView(spkBtn)
            }
            val mid = LinearLayout(this@InCallActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(12), 0, 0)
                addView(holdBtn); addView(keyBtn)
            }
            val mid2 = LinearLayout(this@InCallActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(12), 0, 0)
                addView(mergeBtn); addView(routeBtn); addView(recBtn)
            }
            val bottom = LinearLayout(this@InCallActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(20), 0, 0)
                addView(endBtn)
            }
            addView(top); addView(mid); addView(mid2); addView(bottom)
        }

        root.addView(nameTv); root.addView(numTv); root.addView(stateTv); root.addView(simTv)
        root.addView(spacer); root.addView(ringRow); root.addView(ongoingRow)
        setContentView(root)

        CallHolder.listener = { refresh() }
        handle(intent)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: android.content.Intent?) {
        if (i?.getStringExtra("act") == "answer") CallHolder.primary()?.answer(VideoProfile.STATE_AUDIO_ONLY)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        CallHolder.listener = { refresh() }
        h.post(tick)
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { rec?.release() } catch (e: Exception) { }
        rec = null
        CallHolder.listener = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { moveTaskToBack(true) }

    // Call ke dauran keypad: press par DTMF tone chalta hai, chhodne par ruk jaata hai
    private fun showKeypad() {
        val keys = listOf("123", "456", "789", "*0#")
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(8)) }
        keys.forEach { row ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { ch ->
                r.addView(Button(this).apply {
                    text = ch.toString(); textSize = 22f; isAllCaps = false
                    layoutParams = LinearLayout.LayoutParams(0, dp(60), 1f)
                    setOnTouchListener { _, e ->
                        val c = CallHolder.primary()
                        if (e.action == MotionEvent.ACTION_DOWN) c?.playDtmfTone(ch)
                        else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) c?.stopDtmfTone()
                        false
                    }
                })
            }
            col.addView(r)
        }
        AlertDialog.Builder(this).setView(col).setPositiveButton("Close", null).show()
    }

    // Recording: Android 10+ par third-party app ko call ki dono taraf ki awaaz nahi milti.
    // Isliye mic se record hota hai (speaker par dono awaaz aati hain, warna sirf aapki).
    private fun toggleRecord() {
        if (rec != null) { stopRecord(); return }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 77); return
        }
        try {
            val dir = File(getExternalFilesDir(null), "recordings").apply { mkdirs() }
            val num = CallHolder.primary()?.let { CallHolder.numberOf(it) }.orEmpty().filter { it.isDigit() || it == '+' }
            val f = File(dir, "call_${num}_${System.currentTimeMillis()}.m4a")
            rec = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(f.absolutePath)
                prepare(); start()
            }
            android.widget.Toast.makeText(this, "Recording: " + f.name, android.widget.Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            rec = null
            android.widget.Toast.makeText(this, "Recording nahi ho payi", android.widget.Toast.LENGTH_SHORT).show()
        }
        refresh()
    }

    private fun stopRecord() {
        try { rec?.stop() } catch (e: Exception) { }
        try { rec?.release() } catch (e: Exception) { }
        rec = null
        refresh()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (rc == 77 && r.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) toggleRecord()
    }

    private fun simLabel(c: Call): String = try {
        val h = c.details?.accountHandle
        val tm = getSystemService(TelecomManager::class.java)
        if (h != null && tm.callCapablePhoneAccounts.size > 1) tm.getPhoneAccount(h)?.label?.toString().orEmpty() else ""
    } catch (e: Exception) { "" }

    private fun refresh() {
        val c = CallHolder.primary()
        if (c == null) { stopRecord(); finish(); return }
        val num = CallHolder.numberOf(c)
        if (num != lastNumber) {
            lastNumber = num
            nameTv.text = if (num.isEmpty()) "Unknown" else SmsHelper.nameFor(this, num)
            numTv.text = if (num.isEmpty() || nameTv.text == num) "" else num
        }
        val ringing = c.state == Call.STATE_RINGING
        ringRow.visibility = if (ringing) View.VISIBLE else View.GONE
        ongoingRow.visibility = if (ringing) View.GONE else View.VISIBLE
        stateTv.text = when (c.state) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_DIALING, Call.STATE_CONNECTING, Call.STATE_PULLING_CALL -> "Calling…"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "Call khatam"
            Call.STATE_ACTIVE -> {
                val t = c.details?.connectTimeMillis ?: 0L
                if (t > 0) {
                    val s = ((System.currentTimeMillis() - t) / 1000).coerceAtLeast(0)
                    String.format("%02d:%02d", s / 60, s % 60)
                } else "Connected"
            }
            else -> ""
        }
        val st = CallHolder.service?.callAudioState
        simTv.text = simLabel(c)
        recBtn.text = if (rec != null) "Stop rec" else "Record"
        holdBtn.text = if (c.state == Call.STATE_HOLDING) "Resume" else "Hold"
        mergeBtn.visibility = if (CallHolder.calls.size >= 2) View.VISIBLE else View.GONE
        routeBtn.text = when (st?.route) {
            CallAudioState.ROUTE_BLUETOOTH -> "Bluetooth"
            CallAudioState.ROUTE_SPEAKER -> "Speaker"
            CallAudioState.ROUTE_WIRED_HEADSET -> "Headset"
            else -> "Earpiece"
        }
        muteBtn.text = if (st?.isMuted == true) "Unmute" else "Mute"
        spkBtn.text = if (st?.route == CallAudioState.ROUTE_SPEAKER) "Speaker off" else "Speaker"
    }
}
