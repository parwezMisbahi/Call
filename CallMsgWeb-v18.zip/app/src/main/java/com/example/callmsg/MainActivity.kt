package com.example.callmsg

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.database.ContentObserver
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import android.telecom.TelecomManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

val PERMS: Array<String> = buildList {
    add(Manifest.permission.CALL_PHONE)
    add(Manifest.permission.READ_PHONE_STATE)
    add(Manifest.permission.READ_CONTACTS)
    add(Manifest.permission.WRITE_CONTACTS)
    add(Manifest.permission.READ_CALL_LOG)
    add(Manifest.permission.READ_SMS)
    add(Manifest.permission.SEND_SMS)
    add(Manifest.permission.RECEIVE_SMS)
    if (Build.VERSION.SDK_INT >= 33) add("android.permission.POST_NOTIFICATIONS")
}.toTypedArray()

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    companion object {
        // bahar se aaya tel: / sms: intent, JS ke uthane tak yahan rakha rehta hai
        @Volatile var pending: String = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.setBackgroundColor(0xFF111111.toInt())
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isVerticalScrollBarEnabled = false
        // pinch zoom band
        web.settings.setSupportZoom(false)
        web.settings.builtInZoomControls = false
        web.settings.displayZoomControls = false
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(p!!.createIntent(), 77)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
        }
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/index.html")
        if (savedInstanceState == null) parseIntent(intent)
    }

    // Bridge se JS chalane ke liye
    fun js(code: String) { runOnUiThread { web.evaluateJavascript(code, null) } }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        parseIntent(intent)
    }

    // tel:9876543210 -> keypad mein number; sms:/smsto: -> message compose
    private fun parseIntent(i: Intent?) {
        if (i == null) return
        if ((i.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0) return
        val data = i.data ?: return
        val scheme = (data.scheme ?: "").lowercase()
        val raw = Uri.decode(data.schemeSpecificPart ?: "").substringBefore('?').trim()
        val o = JSONObject()
        when (scheme) {
            "tel" -> o.put("k", "dial").put("n", raw)
            "sms", "smsto", "mms", "mmsto" -> {
                val body = i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
                o.put("k", "sms").put("n", raw).put("b", body)
            }
            else -> return
        }
        pending = o.toString()
        i.data = null // dobara na chale (rotate / wapas aane par)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else if (requestCode == 78 || requestCode == 79) {
            // default Phone / SMS app ka jawab aa gaya
            web.evaluateJavascript("if(window.refreshAll)refreshAll()", null)
        } else if (requestCode == 80 || requestCode == 81) {
            // SMS backup (80) / restore (81): file chun li gayi
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null) {
                Thread {
                    val msg = try {
                        if (requestCode == 80) Backup.write(this, uri) else Backup.read(this, uri)
                    } catch (e: Exception) { "Error: ${e.message}" }
                    runOnUiThread {
                        web.evaluateJavascript("toast(" + JSONObject.quote(msg) + ");if(window.refreshAll)refreshAll()", null)
                    }
                }.start()
            }
        } else if (requestCode == 85) {
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null) {
                Thread {
                    val m = try { BackupXml.write(this, uri) } catch (e: Exception) { "Error: ${e.message}" }
                    js("toast(" + JSONObject.quote(m) + ")")
                }.start()
            }
        } else if (requestCode == 84) {
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null) {
                Thread {
                    val m = try { CallExport.write(this, uri) } catch (e: Exception) { "Error: ${e.message}" }
                    js("toast(" + JSONObject.quote(m) + ")")
                }.start()
            }
        } else if (requestCode == 82) {
            val u = data?.getParcelableExtra<Uri>(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            if (resultCode == RESULT_OK && pendingContactId != 0L) {
                val m = ContactTools.setRingtone(this, pendingContactId, u)
                web.evaluateJavascript("toast(" + JSONObject.quote(m) + ")", null)
            }
        } else if (requestCode == 83) {
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null && pendingContactId != 0L) {
                val id = pendingContactId
                Thread {
                    val m = ContactTools.setPhoto(this, id, uri)
                    runOnUiThread { web.evaluateJavascript("toast(" + JSONObject.quote(m) + ")", null) }
                }.start()
            }
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript(
            "if(window.refreshAll)refreshAll();if(window.handleExternal)handleExternal()", null
        )
    }

    // back dabane par pehle page ke andar ka layer band ho (keypad / thread), phir app
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.handleBack?handleBack():false") { r ->
            if (r != "true") finish()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        web.evaluateJavascript("onPermissionResult()", null)
    }
}

// JavaScript se yeh functions Android.xxx() naam se call hote hain
class Bridge(private val act: Activity) {

    // Har 5 sec ki polling par baar-baar poori query na chale: data badle tabhi dobara padho
    private class Cache {
        @Volatile var v = ""
        @Volatile var ok = false
        @Volatile var t = 0L
        @Volatile var gen = 0
        @Volatile var busy = false
    }
    private val cContacts = Cache()
    private val cCalls = Cache()
    private val cSms = Cache()

    private fun watch(uri: Uri, c: Cache, q: () -> String) {
        try {
            act.contentResolver.registerContentObserver(uri, true,
                object : ContentObserver(Handler(Looper.getMainLooper())) {
                    override fun onChange(selfChange: Boolean) { c.gen++; refresh(c, q) }
                })
        } catch (e: Exception) { }
    }

    init {
        watch(ContactsContract.Contacts.CONTENT_URI, cContacts) { queryContacts() }
        watch(ContactsContract.Data.CONTENT_URI, cContacts) { queryContacts() }
        watch(CallLog.Calls.CONTENT_URI, cCalls) { queryCalls() }
        watch(Telephony.Sms.CONTENT_URI, cSms) { querySms() }
    }

    // Background thread par data taiyaar rakho: JS ka getSms()/getCalls() turant cache se laut aaye, UI thread atke nahi
    private fun refresh(c: Cache, q: () -> String) {
        if (c.busy || !granted()) return
        c.busy = true
        Thread {
            try {
                var n = 0
                do {
                    val g = c.gen
                    val v = q()
                    c.v = v; c.t = System.currentTimeMillis(); c.ok = true
                    n++
                } while (g != c.gen && n < 3)
            } catch (e: Exception) { } finally { c.busy = false }
        }.start()
    }

    private fun cached(c: Cache, q: () -> String): String {
        if (c.ok) {
            if (System.currentTimeMillis() - c.t > 30000) refresh(c, q)
            return c.v
        }
        val g = c.gen
        val v = q()
        if (granted() && g == c.gen) { c.v = v; c.t = System.currentTimeMillis(); c.ok = true }
        return v
    }

    private fun granted() = PERMS.all {
        act.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    @JavascriptInterface
    fun hasPermission(): Boolean = granted()

    @JavascriptInterface
    fun takePending(): String {
        val p = MainActivity.pending
        MainActivity.pending = ""
        return p
    }

    // ---- default Phone / SMS app ----
    @JavascriptInterface
    fun isDefaultDialer(): Boolean {
        try { if (act.getSystemService(TelecomManager::class.java).defaultDialerPackage == act.packageName) return true } catch (e: Exception) { }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = act.getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleHeld(RoleManager.ROLE_DIALER)) return true
            }
        } catch (e: Exception) { }
        return false
    }

    @JavascriptInterface
    fun isDefaultSms(): Boolean = SmsHelper.isDefaultSms(act)

    @JavascriptInterface
    fun requestDefaultDialer() {
        act.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    val rm = act.getSystemService(RoleManager::class.java)
                    if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER))
                        act.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 78)
                } else {
                    act.startActivityForResult(
                        Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                            .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, act.packageName), 78
                    )
                }
            } catch (e: Exception) { }
        }
    }

    @JavascriptInterface
    fun requestDefaultSms() {
        act.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    val rm = act.getSystemService(RoleManager::class.java)
                    if (rm.isRoleAvailable(RoleManager.ROLE_SMS) && !rm.isRoleHeld(RoleManager.ROLE_SMS))
                        act.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 79)
                } else {
                    act.startActivityForResult(
                        Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                            .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, act.packageName), 79
                    )
                }
            } catch (e: Exception) { }
        }
    }

    @JavascriptInterface
    fun requestPermission() {
        act.runOnUiThread { act.requestPermissions(PERMS, 1) }
    }

    @JavascriptInterface
    fun getContacts(): String = cached(cContacts) { queryContacts() }

    private fun queryContacts(): String {
        val arr = JSONArray()
        if (!granted()) return arr.toString()
        try {
            val name = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            val num = ContactsContract.CommonDataKinds.Phone.NUMBER
            act.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(name, num), null, null, "$name ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    arr.put(JSONObject().put("n", c.getString(0) ?: "").put("p", c.getString(1) ?: ""))
                }
            }
        } catch (e: Exception) { }
        return arr.toString()
    }

    // Phone + jo accounts (Gmail/Outlook etc) contacts mein maujood hain, unki list
    @JavascriptInterface
    fun getAccounts(): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("n", "").put("t", ""))
        if (!granted()) return arr.toString()
        val skip = listOf("whatsapp", "telegram", "signal", "thoughtcrime", "viber", "facebook",
            "instagram", "skype", "linkedin", "tachyon", "truecaller", ".sim", "contact.sim")
        val seen = HashSet<String>()
        try {
            act.contentResolver.query(
                ContactsContract.RawContacts.CONTENT_URI,
                arrayOf(ContactsContract.RawContacts.ACCOUNT_NAME, ContactsContract.RawContacts.ACCOUNT_TYPE),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: ""
                    val t = c.getString(1) ?: ""
                    if (n.isEmpty() || t.isEmpty()) continue
                    if (skip.any { t.lowercase().contains(it) }) continue
                    if (seen.add("$t|$n")) arr.put(JSONObject().put("n", n).put("t", t))
                }
            }
        } catch (e: Exception) { }
        return arr.toString()
    }

    // naya contact: at/an = account type/name (khali ho to sirf phone mein)
    @JavascriptInterface
    fun saveContact(json: String): String {
        if (!granted()) return "Error: permission nahi hai"
        return try {
            val o = JSONObject(json)
            val name = o.optString("n").trim()
            val phone = o.optString("p").trim()
            val email = o.optString("e").trim()
            val org = o.optString("o").trim()
            val note = o.optString("note").trim()
            val at = o.optString("at")
            val an = o.optString("an")
            if (name.isEmpty() && phone.isEmpty() && email.isEmpty()) return "Error: naam ya number daalo"
            val ops = ArrayList<ContentProviderOperation>()
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, at.ifEmpty { null })
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, an.ifEmpty { null })
                    .build()
            )
            fun data(mime: String, vararg kv: Pair<String, Any>) {
                val b = ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, mime)
                kv.forEach { b.withValue(it.first, it.second) }
                ops.add(b.build())
            }
            if (name.isNotEmpty()) data(
                ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME to name
            )
            if (phone.isNotEmpty()) data(
                ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.Phone.NUMBER to phone,
                ContactsContract.CommonDataKinds.Phone.TYPE to ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
            )
            if (email.isNotEmpty()) data(
                ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.Email.ADDRESS to email,
                ContactsContract.CommonDataKinds.Email.TYPE to ContactsContract.CommonDataKinds.Email.TYPE_HOME
            )
            if (org.isNotEmpty()) data(
                ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.Organization.COMPANY to org
            )
            if (note.isNotEmpty()) data(
                ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.Note.NOTE to note
            )
            act.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            cContacts.gen++; cContacts.ok = false
            "ok"
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    // a=number, c=saved name, d=time, t=type (1 in, 2 out, 3 missed...), du=seconds
    @JavascriptInterface
    fun getCalls(): String = cached(cCalls) { queryCalls() }

    private fun queryCalls(): String {
        val arr = JSONArray()
        if (!granted()) return arr.toString()
        try {
            act.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE,
                    CallLog.Calls.TYPE, CallLog.Calls.DURATION, CallLog.Calls._ID
                ),
                null, null, "date DESC"
            )?.use { c ->
                while (c.moveToNext() && arr.length() < 200) {
                    arr.put(
                        JSONObject()
                            .put("a", c.getString(0) ?: "")
                            .put("c", c.getString(1) ?: "")
                            .put("d", c.getLong(2))
                            .put("t", c.getInt(3))
                            .put("du", c.getLong(4))
                            .put("i", c.getLong(5))
                    )
                }
            }
        } catch (e: Exception) { }
        return arr.toString()
    }

    @JavascriptInterface
    fun getSms(): String = cached(cSms) { querySms() }

    private fun querySms(): String {
        val arr = JSONArray()
        if (!granted()) return arr.toString()
        try {
            act.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms._ID),
                null, null, "date DESC"
            )?.use { c ->
                while (c.moveToNext() && arr.length() < 600) {
                    arr.put(
                        JSONObject()
                            .put("a", c.getString(0) ?: "")
                            .put("b", c.getString(1) ?: "")
                            .put("d", c.getLong(2))
                            .put("s", c.getInt(3) in intArrayOf(2, 4, 5, 6))
                            .put("ty", c.getInt(3))
                            .put("i", c.getLong(4))
                    )
                }
            }
            val mm = MmsReader.query(act)
            for (i in 0 until mm.length()) arr.put(mm.getJSONObject(i))
        } catch (e: Exception) { }
        return arr.toString()
    }

    @JavascriptInterface
    fun sendSms(to: String, text: String): String = try {
        SmsHelper.send(act, to, text)
        cSms.gen++; cSms.ok = false
        "ok"
    } catch (e: Exception) {
        "Error: ${e.message}"
    }

    // d = message ki date (JS se), taaki gaya / fail / deliver ka status usi se jude
    @JavascriptInterface
    fun sendSmsAt(to: String, text: String, d: String): String = try {
        SmsHelper.send(act, to, text, d.toLongOrNull() ?: System.currentTimeMillis())
        cSms.gen++; cSms.ok = false
        "ok"
    } catch (e: Exception) {
        "Error: ${e.message}"
    }

    @JavascriptInterface
    fun getSmsStatus(): String = SmsHelper.statusJson(act)

    // ---- delete: call log entries / SMS (SMS ke liye default SMS app hona zaroori) ----
    @JavascriptInterface
    fun deleteCalls(idsJson: String): String = try {
        if (act.checkSelfPermission(Manifest.permission.WRITE_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            act.runOnUiThread { act.requestPermissions(arrayOf(Manifest.permission.WRITE_CALL_LOG), 2) }
            "Allow call log access, then swipe again"
        } else {
            val a = JSONArray(idsJson)
            var n = 0
            for (i in 0 until a.length()) {
                n += act.contentResolver.delete(ContentUris.withAppendedId(CallLog.Calls.CONTENT_URI, a.getLong(i)), null, null)
            }
            cCalls.gen++; cCalls.ok = false
            if (n > 0) "ok" else "Could not delete"
        }
    } catch (e: Exception) {
        "Error: ${e.message}"
    }

    @JavascriptInterface
    fun deleteSms(idsJson: String): String = try {
        // pehle seedha delete try karo (default hone ka check galat ho sakta hai); asli natija rows se pata chalta hai
        val a = JSONArray(idsJson)
        var n = 0
        for (i in 0 until a.length()) {
            n += act.contentResolver.delete(ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, a.getLong(i)), null, null)
        }
        cSms.gen++; cSms.ok = false
        if (n > 0) "ok" else "Set CallMsg as default SMS app to delete messages"
    } catch (e: SecurityException) {
        "Set CallMsg as default SMS app to delete messages"
    } catch (e: Exception) {
        "Error: ${e.message}"
    }

    // WhatsApp chat kholo. 10 digit number par India ka code 91 lagta hai (doosre desh ho to yahan badlo)
    @JavascriptInterface
    fun whatsapp(number: String): String {
        var d = number.filter { it.isDigit() }
        if (!number.trim().startsWith("+")) {
            d = d.trimStart('0')
            if (d.length == 10) d = "91$d"
        }
        val uri = Uri.parse("https://wa.me/$d")
        return try {
            act.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
            "ok"
        } catch (e: Exception) {
            try {
                act.startActivity(Intent(Intent.ACTION_VIEW, uri))
                "ok"
            } catch (e2: Exception) {
                "Error: ${e2.message}"
            }
        }
    }

    // ---- call blocking ----
    // list: ["9876543210", "140*"]
    @JavascriptInterface
    fun getBlocked(): String {
        val a = JSONArray()
        Blocklist.list(act).forEach { a.put(it) }
        return a.toString()
    }

    @JavascriptInterface
    fun blockNumber(n: String): String =
        if (Blocklist.add(act, n)) "ok" else "Sahi number daalo"

    @JavascriptInterface
    fun unblockNumber(n: String): String { Blocklist.remove(act, n); return "ok" }

    @JavascriptInterface
    fun isBlockedNumber(n: String): Boolean = n.isNotBlank() && Blocklist.isBlocked(act, n)

    @JavascriptInterface
    fun getBlockPrivate(): Boolean = Blocklist.blockPrivate(act)

    @JavascriptInterface
    fun setBlockPrivate(v: Boolean) { Blocklist.setBlockPrivate(act, v) }

    // ---- batch 2: OTP copy, auto-reply, scheduled SMS, backup / restore ----
    @JavascriptInterface
    fun copyText(t: String) { try { Clip.copy(act, t) } catch (e: Exception) { } }

    @JavascriptInterface
    fun getAutoReply(): String = AutoReply.get(act).toString()

    @JavascriptInterface
    fun setAutoReply(json: String): String = try {
        AutoReply.set(act, JSONObject(json)); "ok"
    } catch (e: Exception) { "Error: ${e.message}" }

    @JavascriptInterface
    fun scheduleSms(to: String, text: String, at: String): String {
        val t = at.toLongOrNull() ?: return "Time galat hai"
        if (to.count { it.isDigit() } < 3) return "Sahi number daalo"
        if (text.isBlank()) return "Message likho"
        if (t < System.currentTimeMillis() + 10000L) return "Aage ka time chuno"
        if (act.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return "SMS permission do"
        return try { Scheduler.add(act, to.trim(), text, t); "ok" } catch (e: Exception) { "Error: ${e.message}" }
    }

    @JavascriptInterface
    fun getScheduled(): String = Scheduler.list(act).toString()

    @JavascriptInterface
    fun cancelScheduled(id: String): String { Scheduler.cancel(act, id.toIntOrNull() ?: 0); return "ok" }

    @JavascriptInterface
    fun exactAlarmOk(): Boolean = try { Scheduler.exactOk(act) } catch (e: Exception) { true }

    @JavascriptInterface
    fun requestExactAlarm() {
        act.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= 31) act.startActivity(
                    Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + act.packageName))
                )
            } catch (e: Exception) { }
        }
    }

    @JavascriptInterface
    fun startBackup(): String {
        val name = "callmsg-backup-" + java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(java.util.Date()) + ".json"
        act.runOnUiThread {
            try {
                act.startActivityForResult(
                    Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("application/json").putExtra(Intent.EXTRA_TITLE, name), 80
                )
            } catch (e: Exception) { }
        }
        return "ok"
    }

    @JavascriptInterface
    fun startRestore(): String {
        if (!SmsHelper.isDefaultSms(act)) return "Restore ke liye CallMsg ko default SMS app banao"
        act.runOnUiThread {
            try {
                act.startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 81
                )
            } catch (e: Exception) { }
        }
        return "ok"
    }

    // ---- XML backup, MMS photo, floating bubble ----
    @JavascriptInterface
    fun startBackupXml(): String {
        val name = "callmsg-backup-" + java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(java.util.Date()) + ".xml"
        act.runOnUiThread {
            try {
                act.startActivityForResult(
                    Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("text/xml").putExtra(Intent.EXTRA_TITLE, name), 85
                )
            } catch (e: Exception) { }
        }
        return "ok"
    }

    @JavascriptInterface
    fun getMmsImage(part: String): String = MmsReader.image(act, part.toLongOrNull() ?: 0L)

    @JavascriptInterface
    fun getBubble(): Boolean = CallBubble.enabled(act) && CallBubble.canDraw(act)

    @JavascriptInterface
    fun setBubble(v: Boolean): String {
        CallBubble.setEnabled(act, v)
        if (v && !CallBubble.canDraw(act)) {
            act.runOnUiThread {
                try {
                    act.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName)))
                } catch (e: Exception) { }
            }
            return "perm"
        }
        return "ok"
    }

    // ---- app lock (fingerprint), hidden sync, call log export ----
    @JavascriptInterface
    fun biometricAvailable(): Boolean = try {
        if (Build.VERSION.SDK_INT < 29) false
        else act.getSystemService(android.hardware.biometrics.BiometricManager::class.java)
            .canAuthenticate() == android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun biometricAuth() {
        if (Build.VERSION.SDK_INT < 29) return
        act.runOnUiThread {
            try {
                val ex = act.mainExecutor
                val cb = object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(r: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) {
                        (act as? MainActivity)?.js("if(window.lockOk)lockOk()")
                    }
                }
                android.hardware.biometrics.BiometricPrompt.Builder(act)
                    .setTitle("CallMsg unlock")
                    .setNegativeButton("PIN use karo", ex) { _, _ -> }
                    .build()
                    .authenticate(android.os.CancellationSignal(), ex, cb)
            } catch (e: Exception) { }
        }
    }

    @JavascriptInterface
    fun setHidden(json: String) { HiddenStore.set(act, json) }

    @JavascriptInterface
    fun exportCalls(): String {
        val name = "call-log-" + java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(java.util.Date()) + ".csv"
        act.runOnUiThread {
            try {
                act.startActivityForResult(
                    Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("text/csv").putExtra(Intent.EXTRA_TITLE, name), 84
                )
            } catch (e: Exception) { }
        }
        return "ok"
    }

    // ---- duplicates / merge / ringtone / photo ----
    @JavascriptInterface
    fun getDuplicates(): String {
        val out = JSONArray()
        if (!granted()) return out.toString()
        try {
            val P = ContactsContract.CommonDataKinds.Phone
            val byName = HashMap<String, MutableSet<Long>>()
            val byNum = HashMap<String, MutableSet<Long>>()
            val names = HashMap<Long, String>()
            act.contentResolver.query(P.CONTENT_URI, arrayOf(P.CONTACT_ID, P.DISPLAY_NAME, P.NUMBER), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0); val n = c.getString(1) ?: ""; val p = Blocklist.norm(c.getString(2) ?: "")
                    names[id] = n
                    if (n.isNotBlank()) byName.getOrPut(n.trim().lowercase()) { HashSet() }.add(id)
                    if (p.length >= 7) byNum.getOrPut(p) { HashSet() }.add(id)
                }
            }
            val seen = HashSet<String>()
            for (g in byName.values + byNum.values) {
                if (g.size < 2) continue
                val ids = g.sorted()
                if (seen.add(ids.joinToString(","))) out.put(JSONObject().put("ids", JSONArray(ids)).put("n", names[ids[0]] ?: ""))
            }
        } catch (e: Exception) { }
        return out.toString()
    }

    @JavascriptInterface
    fun mergeContacts(idsJson: String): String = try {
        if (!granted()) "Error: permission nahi hai" else {
            val ids = JSONArray(idsJson)
            val raws = ArrayList<Long>()
            for (i in 0 until ids.length()) act.contentResolver.query(
                ContactsContract.RawContacts.CONTENT_URI, arrayOf(ContactsContract.RawContacts._ID),
                ContactsContract.RawContacts.CONTACT_ID + "=?", arrayOf(ids.getLong(i).toString()), null
            )?.use { while (it.moveToNext()) raws.add(it.getLong(0)) }
            val ops = ArrayList<ContentProviderOperation>()
            for (i in 1 until raws.size) ops.add(
                ContentProviderOperation.newUpdate(ContactsContract.AggregationExceptions.CONTENT_URI)
                    .withValue(ContactsContract.AggregationExceptions.TYPE, ContactsContract.AggregationExceptions.TYPE_KEEP_TOGETHER)
                    .withValue(ContactsContract.AggregationExceptions.RAW_CONTACT_ID1, raws[0])
                    .withValue(ContactsContract.AggregationExceptions.RAW_CONTACT_ID2, raws[i]).build()
            )
            if (ops.isNotEmpty()) act.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            cContacts.gen++; cContacts.ok = false
            "ok"
        }
    } catch (e: Exception) { "Error: ${e.message}" }

    private fun contactIdFor(number: String): Long {
        try {
            val u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            act.contentResolver.query(u, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)?.use {
                if (it.moveToFirst()) return it.getLong(0)
            }
        } catch (e: Exception) { }
        return 0L
    }

    @JavascriptInterface
    fun pickRingtone(number: String): String {
        val id = contactIdFor(number)
        if (id == 0L) return "Error: pehle contact save karo"
        pendingContactId = id
        act.runOnUiThread {
            act.startActivityForResult(
                Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER)
                    .putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_RINGTONE), 82
            )
        }
        return "ok"
    }

    @JavascriptInterface
    fun pickPhoto(number: String): String {
        val id = contactIdFor(number)
        if (id == 0L) return "Error: pehle contact save karo"
        pendingContactId = id
        act.runOnUiThread {
            act.startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 83)
        }
        return "ok"
    }

    // Dual SIM: 2+ SIM hon to pehle chunne ka dialog, warna seedha call
    private fun place(number: String, h: android.telecom.PhoneAccountHandle?) {
        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
        if (h != null) i.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, h)
        act.startActivity(i)
    }

    @JavascriptInterface
    fun call(number: String): String = try {
        val tm = act.getSystemService(TelecomManager::class.java)
        val accts = try { tm.callCapablePhoneAccounts } catch (e: SecurityException) { emptyList() }
        if (accts.size > 1) {
            act.runOnUiThread {
                val labels = accts.map { tm.getPhoneAccount(it)?.label?.toString() ?: "SIM" }.toTypedArray()
                android.app.AlertDialog.Builder(act).setTitle("Call with")
                    .setItems(labels) { _, i -> try { place(number, accts[i]) } catch (e: Exception) { } }.show()
            }
        } else place(number, null)
        "ok"
    } catch (e: Exception) {
        "Error: ${e.message}"
    }
}
